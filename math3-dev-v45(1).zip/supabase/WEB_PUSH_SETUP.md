# Math3 Web Push — Dev setup

This version does not change Stable.

## Required Supabase Auth setting
Enable **Anonymous Sign-Ins** in Supabase Auth Providers before testing the guest login.

## Required Web Push keys
Generate a VAPID key pair outside the browser and configure:
- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_SUBJECT`

Put only the public key in `index.html` as `math3-vapid-public-key`.
Never put the private key in frontend files or the Library zip.

## Edge Function secrets
`send-web-push` expects:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `VAPID_PUBLIC_KEY`
- `VAPID_PRIVATE_KEY`
- `VAPID_SUBJECT`

The function is intentionally not deployed to Stable as part of this Dev step.

## Notification queue dispatcher

`process-web-push` is the single Web Push dispatcher. It reads the existing `notifications` queue, maps `kind` to the user's notification preference, and sends to every enabled subscription belonging to the notification's existing `notification_deliveries` recipients.

It is idempotent through `web_push_deliveries (notification_id, subscription_id)`, so rerunning the dispatcher does not resend a successful push to the same device.

For Dev deployment, configure the Edge Function secret:
- `MATH3_INTERNAL_PUSH_SECRET`

The scheduler/cron that already processes the notification queue should invoke `process-web-push` periodically with the internal header `x-math3-internal`. Keep the secret server-side; never put it in frontend code.

Mapping:
- `drive_file` / `new_file` → `new_files`
- `reminder` → `reminders`
- `question` / `answer` / `qa` → `qa`
- other notification kinds → `new_posts`

Telegram delivery is untouched. Web Push is an additional channel until Dev E2E testing proves it can replace Telegram notifications safely.


## Dev v45 configuration
- Supabase project: Math3-Dev (`vorzsyrnrrkkdgcytmoz`)
- Frontend now points to the Dev project.
- VAPID public key is embedded in Dev frontend only.
- VAPID private key and `MATH3_INTERNAL_PUSH_SECRET` must never be committed to source.
- Edge Function secrets must be added in Dashboard → Edge Functions → Secrets.
- No Stable project settings, code, migrations, functions, or cron jobs were changed.
