/* Math 3 — module entry point */
import { onTelegramAuth, mountTelegramRedirectButton, readTelegramReturn, onAnonymousLogin } from './app.js?v=58';

// Telegram's widget callback is declared by name in the page markup.
window.onTelegramAuth = onTelegramAuth;
window.mountTelegramRedirectButton = mountTelegramRedirectButton;
window.readTelegramReturn = readTelegramReturn;
window.onAnonymousLogin = onAnonymousLogin;

// Mount Telegram's widget in its dedicated slot; keep the guest option visible.
if (!window.IS_IOS) {
  const slot = document.getElementById('tg-slot');
  if (slot && !slot.firstChild) {
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://telegram.org/js/telegram-widget.js?22';
    script.setAttribute('data-telegram-login', 'MATHDEPARTMENT_BOT');
    script.setAttribute('data-size', 'large');
    script.setAttribute('data-userpic', 'false');
    script.setAttribute('data-onauth', 'onTelegramAuth(user)');
    script.setAttribute('data-request-access', 'write');
    slot.appendChild(script);
  }
}
