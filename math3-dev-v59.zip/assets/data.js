import { sb, say, withTimeout } from "./core.js?v=59";
import { state, isAdmin, isGuest } from "./state.js?v=59";

async function loadCourses() {
  try {
  const requests = [sb.from("courses").select("id,name,sort_order,is_active,drive_url,whatsapp_link,teams_link,telegram_link,youtube_link").order("sort_order").order("name")];
  if (!isGuest()) requests.push(sb.from("user_courses").select("course_id"));
  const results = await withTimeout(Promise.all(requests), 15000, "COURSES_TIMEOUT");
  const c = results[0], u = results[1];
  if (c.error || (!isGuest() && u?.error)) { say("تعذّر تحميل المواد", true); return false; }
  state.courses = c.data || [];
  state.mine = isGuest() ? new Set(state.courses.filter((x) => x.is_active).map((x) => x.id)) : new Set((u?.data || []).map((r) => r.course_id));
  if (isGuest()) state.chosen = true;
  return true;
  } catch (e) { say("تعذّر تحميل المواد — جرّبي تحديث الصفحة", true); return false; }
}

let itemFieldOrderSupported = false;

async function fetchData() {
  try {
  const sectionsQuery = sb.from("sections").select("id,title,kind,sort_order,is_active").order("sort_order");
  if (!isAdmin()) sectionsQuery.eq("is_active", true);
  let itemQuery = sb.from("items").select("id,section_id,course_id,title,body,url,deadline,deadline_has_time,created_at,deleted_at,attachment_kind,attachment_url,attachment_path,attachment_name,attachment_mime,attachment_size,field_order");
  let s, i, p, pi, q, a;
  if (isGuest()) {
    [s, i] = await withTimeout(Promise.all([sectionsQuery, itemQuery]), 20000, "DATA_TIMEOUT");
    p = { data: [], error: null }; pi = { data: [], error: null }; q = { data: [], error: null }; a = { data: [], error: null };
  } else {
    [s, i, p, pi, q, a] = await withTimeout(Promise.all([
      sectionsQuery, itemQuery,
      sb.from("progress").select("item_id,done,submitted"),
      sb.from("personal_items").select("id,title,body,deadline,done,created_at"),
      sb.rpc("get_questions"), sb.rpc("get_answers"),
    ]), 20000, "DATA_TIMEOUT");
  }
  if (i.error && /field_order|column/i.test(i.error.message || "")) {
    itemFieldOrderSupported = false;
    const fallback = await sb.from("items").select("id,section_id,course_id,title,body,url,deadline,deadline_has_time,created_at,deleted_at,attachment_kind,attachment_url,attachment_path,attachment_name,attachment_mime,attachment_size");
    i = fallback;
  } else if (!i.error) {
    itemFieldOrderSupported = true;
  }
  if (s.error || i.error || p.error || pi.error || q.error || a.error) { say("تعذّر تحميل البيانات", true); return false; }
  state.sections = s.data;
  state.items = i.data;
  state.personal = pi.data;
  state.questions = q.data;
  state.answers = a.data;
  const { data: postsData, error: postsError } = await sb
  .from("posts")
  .select("id,content,image_url,created_at,deleted_at")
  .order("created_at", { ascending: false })
  .order("id", { ascending: false });

if (postsError) { say("تعذّر تحميل المنشورات", true); return false; }
  state.posts = postsData || [];
  state.progress = {};
  p.data.forEach((r) => { state.progress[r.item_id] = r; });
  state.qaNames = {};
  if (isAdmin()) {
    const ids = Array.from(new Set([
      ...state.questions.map((x) => x.asker_id),
      ...state.answers.map((x) => x.author_id),
    ]));
    if (ids.length) {
      const np = await sb.from("profiles").select("id,first_name,username").in("id", ids);
      if (!np.error) {
        np.data.forEach((x) => { state.qaNames[x.id] = x.first_name || (x.username ? "@" + x.username : "مستخدم"); });
      }
    }
  }
  if (state.active !== "__posts__" && !state.sections.find((x) => x.id === state.active)) {
    state.active = null;
  }
  const requestedPostId = (() => { const m = location.hash.match(/post=([^&]+)/); return m ? decodeURIComponent(m[1]) : null; })();
  if (requestedPostId != null && state.posts.some((x) => String(x.id) === String(requestedPostId))) {
    state.active = "__posts__";
    state.postFocus = requestedPostId;
  }
  return true;
  } catch (e) { say("تعذّر تحميل البيانات — جرّبي تحديث الصفحة", true); return false; }
}

async function loadData() {
  if (await fetchData()) window.dispatchEvent(new Event("math3:data-loaded"));
}

export { loadCourses, fetchData, loadData, itemFieldOrderSupported };
