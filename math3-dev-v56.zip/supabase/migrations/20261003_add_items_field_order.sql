-- Math3 Dynamic Builder: persist per-item field order.
-- Safe additive migration; existing items remain unchanged.
alter table public.items
  add column if not exists field_order text[];

comment on column public.items.field_order is
  'Ordered dynamic-builder field keys, e.g. {title,body,url,attachment,deadline,course}';


-- No index is required: field_order is presentation metadata, not a filter key.
