import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import webpush from "npm:web-push@3.6.7";
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const authHeader = req.headers.get("Authorization") || "";
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || Deno.env.get("SUPABASE_PUBLISHABLE_KEY")!;
    const client = createClient(supabaseUrl, anonKey, { global: { headers: { Authorization: authHeader } } });
    const { data: { user } } = await client.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const { data: profile } = await client.from("profiles").select("role").eq("id", user.id).maybeSingle();
    if (profile?.role !== "full_admin") return new Response(JSON.stringify({ error: "forbidden" }), { status: 403, headers: { ...cors, "Content-Type": "application/json" } });

    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!serviceKey) throw new Error("SERVICE_ROLE_NOT_CONFIGURED");
    const adminClient = createClient(supabaseUrl, serviceKey);

    const body = await req.json();
    const type = String(body.type || "new_posts");
    const title = String(body.title || "Math 3").slice(0, 120);
    const message = String(body.body || "").slice(0, 500);
    const url = String(body.url || "./");
    const userIds = Array.isArray(body.user_ids) ? body.user_ids : null;

    const vapidPublic = Deno.env.get("VAPID_PUBLIC_KEY");
    const vapidPrivate = Deno.env.get("VAPID_PRIVATE_KEY");
    const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@level3math.github.io";
    if (!vapidPublic || !vapidPrivate) throw new Error("VAPID_NOT_CONFIGURED");
    webpush.setVapidDetails(vapidSubject, vapidPublic, vapidPrivate);

    let q = adminClient.from("push_subscriptions").select("id,user_id,endpoint,p256dh,auth,content_encoding").eq("enabled", true);
    if (userIds?.length) q = q.in("user_id", userIds);
    const { data: subs, error } = await q;
    if (error) throw error;

    const { data: prefs } = await adminClient.from("notification_preferences").select("user_id,enabled,reminders,new_files,new_posts,qa").eq("enabled", true);
    const allowed = new Map((prefs || []).map((p: any) => [p.user_id, p]));
    const prefKey = type === "reminder" ? "reminders" : type === "new_file" ? "new_files" : type === "qa" ? "qa" : "new_posts";

    let sent = 0, failed = 0;
    for (const sub of subs || []) {
      const p = allowed.get(sub.user_id);
      if (!p || p[prefKey] === false) continue;
      try {
        await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify({ title, body: message, url }));
        sent++;
      } catch (e: any) {
        failed++;
        if (e?.statusCode === 404 || e?.statusCode === 410) {
          await adminClient.from("push_subscriptions").delete().eq("id", sub.id);
        }
      }
    }
    return new Response(JSON.stringify({ sent, failed, type }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e?.message || "push_failed" }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
