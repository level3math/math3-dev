import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import webpush from "npm:web-push@3.6.7";
import { createClient } from "jsr:@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-math3-internal" };

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { ...cors, "Content-Type": "application/json" } });
}

function prefKey(kind: string) {
  if (kind === "drive_file" || kind === "new_file") return "new_files";
  if (kind === "reminder") return "reminders";
  if (kind === "question" || kind === "answer" || kind === "qa") return "qa";
  return "new_posts";
}

function notificationPayload(message: string) {
  const lines = String(message || "").split("\n").map(x => x.trim()).filter(Boolean);
  const title = lines[0] || "Math 3";
  const body = lines.slice(1).join("\n") || title;
  return { title: title.slice(0, 120), body: body.slice(0, 500) };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const internal = Deno.env.get("MATH3_INTERNAL_PUSH_SECRET");
    if (!internal || req.headers.get("x-math3-internal") !== internal) return json({ error: "forbidden" }, 403);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const vapidPublic = Deno.env.get("VAPID_PUBLIC_KEY");
    const vapidPrivate = Deno.env.get("VAPID_PRIVATE_KEY");
    const vapidSubject = Deno.env.get("VAPID_SUBJECT") || "mailto:admin@level3math.github.io";
    if (!serviceKey || !vapidPublic || !vapidPrivate) return json({ error: "PUSH_NOT_CONFIGURED" }, 500);

    const admin = createClient(supabaseUrl, serviceKey);
    webpush.setVapidDetails(vapidSubject, vapidPublic, vapidPrivate);

    const body = await req.json().catch(() => ({}));
    const limit = Math.min(Math.max(Number(body.limit) || 20, 1), 100);

    const { data: notifications, error: nErr } = await admin
      .from("notifications")
      .select("id,kind,message,send_after")
      .lte("send_after", new Date().toISOString())
      .order("id", { ascending: true })
      .limit(limit);
    if (nErr) throw nErr;

    let sent = 0, skipped = 0, failed = 0;
    for (const n of notifications || []) {
      const type = prefKey(String(n.kind || ""));
      const { data: deliveries, error: dErr } = await admin
        .from("notification_deliveries")
        .select("user_id,telegram_id")
        .eq("notification_id", n.id);
      if (dErr) { failed++; continue; }

      const userIds = [...new Set((deliveries || []).map((d: any) => d.user_id).filter(Boolean))];
      if (!userIds.length) { skipped++; continue; }

      const { data: prefs } = await admin
        .from("notification_preferences")
        .select("user_id,enabled,reminders,new_files,new_posts,qa")
        .in("user_id", userIds)
        .eq("enabled", true);
      const allowed = new Map((prefs || []).filter((p: any) => p[type] !== false).map((p: any) => [p.user_id, p]));
      const targets = userIds.filter(id => allowed.has(id));
      if (!targets.length) { skipped++; continue; }

      const { data: subs, error: sErr } = await admin
        .from("push_subscriptions")
        .select("id,user_id,endpoint,p256dh,auth")
        .eq("enabled", true)
        .in("user_id", targets);
      if (sErr) { failed++; continue; }

      const payload = notificationPayload(n.message);
      for (const sub of subs || []) {
        const { data: already } = await admin.from("web_push_deliveries").select("id").eq("notification_id", n.id).eq("subscription_id", sub.id).maybeSingle();
        if (already) { skipped++; continue; }
        try {
          await webpush.sendNotification({ endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } }, JSON.stringify({ ...payload, url: "./" , tag: `math3-${n.id}` }));
          await admin.from("web_push_deliveries").insert({ notification_id: n.id, subscription_id: sub.id, user_id: sub.user_id, status: "sent", sent_at: new Date().toISOString() });
          sent++;
        } catch (e: any) {
          failed++;
          await admin.from("web_push_deliveries").insert({ notification_id: n.id, subscription_id: sub.id, user_id: sub.user_id, status: "failed", error: String(e?.message || e).slice(0, 500) }).catch(() => {});
          if (e?.statusCode === 404 || e?.statusCode === 410) await admin.from("push_subscriptions").delete().eq("id", sub.id);
        }
      }
    }

    return json({ processed: notifications?.length || 0, sent, skipped, failed });
  } catch (e: any) {
    return json({ error: e?.message || "push_dispatch_failed" }, 500);
  }
});
