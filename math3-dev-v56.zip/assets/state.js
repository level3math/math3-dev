const roleLabels = { student: "Student", admin: "Admin", full_admin: "Owner" };
const roleRank = { full_admin: 0, admin: 1, student: 2 };
const state = { userId: null, role: null, sections: [], items: [], progress: {},
  personal: [], courses: [], mine: new Set(), chosen: false,
  people: [], peopleQuery: "", peopleLimit: 50, peopleSort: "newest",
  questions: [], answers: [], qaNames: {}, qform: null, answerForm: {},
  posts: [], postForm: null, postFocus: null,
  active: null, filter: "all", trash: false, form: null, pform: null, logLimit: 100, botOk: null, courseAttachmentCourseId: null, courseAttForm: null, isAnonymous: false };
const isAdmin = () => state.role === "admin" || state.role === "full_admin";
const isFull = () => state.role === "full_admin";
const isGuest = () => !!state.isAnonymous;
const courseName = (id) => (state.courses.find((c) => c.id === id) || {}).name || "";

function rpcMsg(error) {
  const m = (error && error.message) || "";
  if (m.includes("last_full_admin")) return "لا يمكن ذلك: لا يمكن حذف أو تغيير المالك الوحيد";
  if (m.includes("cannot_self")) return "لا يمكن تنفيذ ذلك على الحساب الشخصي";
  if (m.includes("not_allowed")) return "غير مسموح";
  return "تعذّر التنفيذ";
}
export { roleLabels, roleRank, state, isAdmin, isFull, isGuest, courseName, rpcMsg };
