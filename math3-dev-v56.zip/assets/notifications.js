import { sb, say, withTimeout } from "./core.js?v=55";

const VAPID_PUBLIC_KEY = (window.MATH3_VAPID_PUBLIC_KEY || "").trim();
const SW_PATH = "./service-worker.js?v=55";

function isSupported() {
  return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
}

function configured() {
  return !!VAPID_PUBLIC_KEY && !VAPID_PUBLIC_KEY.includes("REPLACE_ME");
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

async function getRegistration() {
  return navigator.serviceWorker.register(SW_PATH, { scope: "./" });
}

async function getSubscription() {
  if (!isSupported()) return null;
  const reg = await getRegistration();
  return reg.pushManager.getSubscription();
}

async function saveSubscription(subscription, enabled = true) {
  const user = (await sb.auth.getUser()).data.user;
  if (!user) throw new Error("NO_SESSION");
  const json = subscription.toJSON();
  const keys = json.keys || {};
  const { error } = await sb.from("push_subscriptions").upsert({
    user_id: user.id,
    endpoint: json.endpoint,
    p256dh: keys.p256dh || null,
    auth: keys.auth || null,
    content_encoding: "aes128gcm",
    enabled,
    updated_at: new Date().toISOString(),
  }, { onConflict: "endpoint" });
  if (error) throw error;
}

async function ensurePreferences() {
  const user = (await sb.auth.getUser()).data.user;
  if (!user) return null;
  const { data, error } = await sb.from("notification_preferences")
    .select("enabled,reminders,new_files,new_posts,qa")
    .eq("user_id", user.id).maybeSingle();
  if (error) throw error;
  if (data) return data;
  const defaults = { user_id: user.id, enabled: false, reminders: true, new_files: true, new_posts: true, qa: true };
  const { data: created, error: createError } = await sb.from("notification_preferences").insert(defaults).select("enabled,reminders,new_files,new_posts,qa").single();
  if (createError) throw createError;
  return created;
}

async function getNotificationState() {
  if (!isSupported()) return { supported: false, configured: configured(), permission: Notification.permission, enabled: false, subscription: null, preferences: null };
  let preferences = null;
  try { preferences = await withTimeout(ensurePreferences(), 8000, "NOTIFICATION_PREFS_TIMEOUT"); } catch (e) {}
  const subscription = await getSubscription().catch(() => null);
  return { supported: true, configured: configured(), permission: Notification.permission, enabled: !!preferences?.enabled && !!subscription, subscription, preferences };
}

async function enableNotifications() {
  if (!isSupported()) throw new Error("UNSUPPORTED");
  if (!configured()) throw new Error("VAPID_NOT_CONFIGURED");
  const permission = await Notification.requestPermission();
  if (permission !== "granted") throw new Error("PERMISSION_DENIED");
  const reg = await getRegistration();
  let subscription = await reg.pushManager.getSubscription();
  if (!subscription) {
    subscription = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
    });
  }
  await saveSubscription(subscription, true);
  await sb.from("notification_preferences").upsert({
    user_id: (await sb.auth.getUser()).data.user.id,
    enabled: true,
    updated_at: new Date().toISOString(),
  }, { onConflict: "user_id" });
  return getNotificationState();
}

async function disableNotifications() {
  const user = (await sb.auth.getUser()).data.user;
  if (!user) return;
  const subscription = await getSubscription().catch(() => null);
  if (subscription) {
    await sb.from("push_subscriptions").update({ enabled: false, updated_at: new Date().toISOString() }).eq("endpoint", subscription.endpoint);
  }
  await sb.from("notification_preferences").upsert({ user_id: user.id, enabled: false, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
  return getNotificationState();
}

async function setNotificationType(type, enabled) {
  const allowed = ["reminders", "new_files", "new_posts", "qa"];
  if (!allowed.includes(type)) throw new Error("BAD_NOTIFICATION_TYPE");
  const user = (await sb.auth.getUser()).data.user;
  if (!user) throw new Error("NO_SESSION");
  const patch = { user_id: user.id, [type]: !!enabled, updated_at: new Date().toISOString() };
  const { error } = await sb.from("notification_preferences").upsert(patch, { onConflict: "user_id" });
  if (error) throw error;
  return getNotificationState();
}

function notificationStatusText(s) {
  if (!s.supported) return "المتصفح الحالي لا يدعم إشعارات الموقع.";
  if (!s.configured) return "نظام الإشعارات جاهز، وباقي فقط إعداد مفتاح Web Push على المشروع.";
  if (s.permission === "denied") return "الإشعارات مقفولة من إعدادات المتصفح.";
  if (s.enabled) return "الإشعارات مفعّلة على هذا الجهاز.";
  return "الإشعارات غير مفعّلة على هذا الجهاز.";
}

export { isSupported, configured, getNotificationState, enableNotifications, disableNotifications, setNotificationType, notificationStatusText };
