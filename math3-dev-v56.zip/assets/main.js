/* Math 3 — module entry point */
import { onTelegramAuth, mountTelegramRedirectButton, readTelegramReturn, onAnonymousLogin } from './app.js?v=55';

// Telegram's widget callback is declared by name in the page markup.
window.onTelegramAuth = onTelegramAuth;
window.mountTelegramRedirectButton = mountTelegramRedirectButton;
window.readTelegramReturn = readTelegramReturn;
window.onAnonymousLogin = onAnonymousLogin;
