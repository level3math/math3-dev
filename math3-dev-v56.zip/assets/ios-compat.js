// Math 3 — iOS/Safari compatibility helpers
(function () {
  'use strict';
  var root = document.documentElement;

  function setViewportUnit() {
    try {
      root.style.setProperty('--app-vh', (window.innerHeight * 0.01) + 'px');
    } catch (e) {}
  }

  setViewportUnit();
  window.addEventListener('resize', setViewportUnit, { passive: true });
  window.addEventListener('orientationchange', function () {
    setTimeout(setViewportUnit, 120);
  }, { passive: true });

  // Keep keyboard-open / Safari viewport changes from leaving fixed UI in a bad state.
  window.addEventListener('pageshow', setViewportUnit, { passive: true });

  // iOS standalone/PWA-style mode marker for CSS tweaks without UA sniffing in CSS.
  try {
    if (window.navigator.standalone === true) root.classList.add('ios-standalone');
  } catch (e) {}
})();
