import {
  sb, $, say, el, showLoading, themeSettings, loadThemeSettings, saveThemeSettings,
  applyThemeSettings, resetThemeSettings, fmt, fmtDeadline, tzOffset, localToISO,
  toLocalInput, safeUrl, MAX_ATTACH, WARN_ATTACH, SHRINK_IMAGES, shrinkImage, humanSize,
  uploadAttachment, removeAttachmentFiles, uploadQAAttachment, renderQAAttachment
} from "./core.js";
import { state, isAdmin, isFull, isGuest, courseName, rpcMsg } from "./state.js";
import { getNotificationState, enableNotifications, disableNotifications, setNotificationType, notificationStatusText } from "./notifications.js";
import { loadCourses, loadData, itemFieldOrderSupported } from "./data.js";
import { check, field } from "./ui.js";
import { renderPosts } from "./posts.js";

window.addEventListener("math3:theme-reset", () => renderSettings());
window.addEventListener("math3:data-loaded", () => render());


function goHome() {
  setNavActive("home");
  state.active = null; state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
  state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
  render();
}
function setView(v) {
  $("app").hidden = v !== "app";
  $("picker-box").hidden = v !== "picker";
  $("courses-box").hidden = v !== "courses";
  $("people-box").hidden = v !== "people";
  $("log-box").hidden = v !== "log";
  $("settings-box").hidden = v !== "settings";
  if (v === "picker") renderPicker();
  if (v === "courses") renderCourses();
  if (v === "people") renderPeople(true);
  if (v === "log") renderLog();
  if (v === "settings") renderSettings();
  if (v === "app") goHome();
}
/* الدوس على الخلفية (أي حاجة مش زرار/كارت/تاب) يرجّع للهوم */
document.addEventListener("click", (e) => {
  if ($("app").hidden || !state.active) return;
  if (e.target.closest("button, a, input, textarea, select, .card")) return;
  goHome();
});
async 
async 
async 


/* اختيار المواد */
function renderPicker() {
  const box = $("picker-box");
  box.replaceChildren();
  box.appendChild(el("h3", "", "اختيار المواد"));
  box.appendChild(el("p", "", "اختيار المواد المسجَّل فيها. تظهر التكاليف الخاصة بها فقط، ويمكن تغيير الاختيار في أي وقت."));
  const sel = new Set(state.mine);
  const act = state.courses.filter((c) => c.is_active);
  if (!act.length) box.appendChild(el("p", "meta", "لا توجد مواد بعد"));
  act.forEach((c) => {
    const row = el("div");
    row.appendChild(check(c.name, sel.has(c.id), (v) => { if (v) sel.add(c.id); else sel.delete(c.id); }));
    box.appendChild(row);
  });
  const row = el("div", "row");
  const ok = el("button", "", "حفظ");
  ok.addEventListener("click", async () => {
    ok.disabled = true;
    let e = (await sb.from("user_courses").delete().eq("user_id", state.userId)).error;
    if (!e && sel.size) {
      e = (await sb.from("user_courses").insert(
        [...sel].map((id) => ({ user_id: state.userId, course_id: id }))
      )).error;
    }
    if (!e) e = (await sb.from("profiles").update({ courses_chosen: true }).eq("id", state.userId)).error;
    ok.disabled = false;
    if (e) { say("تعذّر الحفظ"); return; }
    state.chosen = true;
    state.mine = new Set(sel);
    state.filter = "all";
    say("تم الحفظ");
    await loadData();
    setView("app");
  });
  row.appendChild(ok);
  if (state.chosen) {
    const cancel = el("button", "", "إلغاء");
    cancel.addEventListener("click", () => setView("app"));
    row.appendChild(cancel);
  }
  box.appendChild(row);
}
/* إدارة المواد (للأدمنز) */
function renderCourses() {
  if (!isAdmin()) return;
  const box = $("courses-box");
  box.replaceChildren();
  const top = el("div", "row");
  top.appendChild(el("h3", "", "إدارة المواد"));
  const back = el("button", "small", "رجوع");
  back.addEventListener("click", () => setView("app"));
  top.appendChild(back);
  box.appendChild(top);
  const add = el("div", "card");
  const inp = el("input");
  inp.type = "text";
  inp.placeholder = "اسم المادة";
  add.appendChild(inp);
  const b = el("button", "", "إضافة مادة");
  b.style.marginTop = "8px";
  b.addEventListener("click", async () => {
    const name = inp.value.trim();
    if (!name) { say("اسم المادة مطلوب"); return; }
    const next = state.courses.reduce((m, c) => Math.max(m, c.sort_order), 0) + 1;
    const { error } = await sb.from("courses").insert({ name, sort_order: next });
    if (error) { say(error.code === "23505" ? "المادة موجودة بالفعل" : "تعذّر الحفظ"); return; }
    say("تمت الإضافة");
    await loadCourses();
    renderCourses();
  });
  add.appendChild(b);
  box.appendChild(add);
  state.courses.forEach((c) => {
    const card = el("div", "card");
    card.appendChild(el("h3", "", c.name + (c.is_active ? "" : " (متوقفة)")));
    const row = el("div", "row");
    const rn = el("button", "small", "تعديل الاسم");
    rn.addEventListener("click", async () => {
      const name = (prompt("الاسم الجديد", c.name) || "").trim();
      if (!name || name === c.name) return;
      const { error } = await sb.from("courses").update({ name }).eq("id", c.id);
      if (error) { say(error.code === "23505" ? "الاسم مستخدم بالفعل" : "تعذّر الحفظ"); return; }
      say("");
      await loadCourses();
      renderCourses();
    });
    const tg = el("button", "small", c.is_active ? "إيقاف" : "تفعيل");
    tg.addEventListener("click", async () => {
      const { error } = await sb.from("courses").update({ is_active: !c.is_active }).eq("id", c.id);
      if (error) { say("تعذّر الحفظ"); return; }
      say("");
      await loadCourses();
      renderCourses();
    });
    row.appendChild(rn);
    row.appendChild(tg);
    [
      { key: "whatsapp_link", label: "واتساب" },
      { key: "teams_link", label: "تيمز" },
      { key: "telegram_link", label: "تيليجرام" },
      { key: "youtube_link", label: "يوتيوب" },
    ].forEach((k) => {
      const lb = el("button", "small", (c[k.key] ? "تعديل لينك " : "إضافة لينك ") + k.label);
      lb.addEventListener("click", async () => {
        const raw = prompt("رابط " + k.label + " بتاع " + c.name, c[k.key] || "");
        if (raw === null) return;
        const url = raw.trim();
        const u = url || null;
        if (u === (c[k.key] || null)) return;
        const { error } = await sb.from("courses").update({ [k.key]: u }).eq("id", c.id);
        if (error) { say("تعذّر الحفظ"); return; }
        say("");
        await loadCourses();
        renderCourses();
      });
      row.appendChild(lb);
    });
    if (isFull()) {
      const del = el("button", "small danger", "حذف");
      del.addEventListener("click", async () => {
        if (!confirm("حذف المادة نهائيًا؟ سيتم إلغاء تسجيل الناس فيها ولا يمكن التراجع.")) return;
        const { data, error } = await sb.from("courses").delete().eq("id", c.id).select("id");
        if (error) {
          say(error.code === "23503"
            ? "المادة مرتبطة بعناصر (حتى الموجودة في السلة). الأفضل إيقافها، أو حذف عناصرها أولًا."
            : "تعذّر الحذف");
          return;
        }
        if (!data || !data.length) { say("تعذّر الحذف"); return; }
        say("تم الحذف");
        await loadCourses();
        renderCourses();
      });
      row.appendChild(del);
    }
    card.appendChild(row);
    box.appendChild(card);
  });
}
/* users — الصلاحيات مرتبطة بـ Step 2: Admin قراءة فقط، Full Admin إدارة كاملة */
const MANAGEABLE_USER_ROLES = ["student", "admin", "full_admin"];

async function changeRole(p, role, sel) {
  if (!isFull() || p.id === state.userId) { sel.value = p.role; say("غير مسموح"); return; }
  if (!MANAGEABLE_USER_ROLES.includes(role)) { sel.value = p.role; say("دور غير صالح"); return; }
  if (role === p.role) return;
  if (!confirm("تغيير دور " + (p.first_name || "هذا الحساب") + " إلى " + roleLabels[role] + "؟")) {
    sel.value = p.role;
    return;
  }
  const { error } = await sb.rpc("set_role", { target: p.id, new_role: role });
  if (error) { sel.value = p.role; say(rpcMsg(error)); return; }
  say("تم تغيير الدور");
  await renderPeople(true);
}
async function toggleBlock(p) {
  if (!isFull() || p.id === state.userId) { say("غير مسموح"); return; }
  const block = p.approved;
  const q = block
    ? "إيقاف هذا الحساب؟ لن يرى أي محتوى حتى يتم تفعيله."
    : "تفعيل هذا الحساب؟";
  if (!confirm(q)) return;
  const { error } = await sb.rpc("set_blocked", { target: p.id, blocked: block });
  if (error) { say(rpcMsg(error)); return; }
  say(block ? "تم إيقاف الحساب" : "تم تفعيل الحساب");
  await renderPeople(true);
}
async function deletePerson(p) {
  if (!isFull() || p.id === state.userId) { say("غير مسموح"); return; }
  if (!confirm("حذف " + (p.first_name || "هذا الحساب") + " من الـ users؟\nهيقدر يرجع يظهر تاني لو عمل تسجيل دخول بتيليجرام من جديد.")) return;
  const { error } = await sb.rpc("delete_profile", { target: p.id });
  if (error) { say(rpcMsg(error)); return; }
  say("تم الحذف");
  await renderPeople(true);
}
function personCard(p) {
  const c = el("article", "card people-card");
  const head = el("div", "people-card-head");
  const name = el("div");
  name.appendChild(el("h3", "", p.first_name || "—"));
  name.appendChild(el("p", "meta", p.username ? "@" + p.username : "بدون يوزر"));
  head.appendChild(name);
  const badge = el("span", "people-role-badge", roleLabels[p.role] || p.role);
  if (!p.approved) badge.classList.add("is-muted");
  head.appendChild(badge);
  c.appendChild(head);

  const status = el("div", "people-status-row");
  status.appendChild(el("span", "", p.approved ? "الحساب مفعّل" : "الحساب موقوف"));
  status.appendChild(el("span", "people-status-muted", p.bot_ok === false ? "تيليجرام: متوقف" : "تيليجرام: متصل"));
  status.appendChild(el("span", "people-status-muted", p.courses_chosen ? "اختار المواد" : "لم يختر المواد"));
  c.appendChild(status);
  c.appendChild(el("p", "people-created", "تاريخ الإنشاء: " + peopleDate(p.created_at)));

  if (p.id === state.userId) {
    c.appendChild(el("p", "people-current", "هذا هو الحساب الحالي"));
    return c;
  }

  if (!isFull()) {
    c.appendChild(el("p", "people-readonly", "عرض فقط — وفق صلاحيات النظام، الـAdmin يستطيع القراءة فقط."));
    return c;
  }

  const row = el("div", "row people-actions");
  const sel = el("select");
  sel.setAttribute("aria-label", "دور المستخدم");
  MANAGEABLE_USER_ROLES.forEach((r) => {
    const o = el("option", "", roleLabels[r]);
    o.value = r;
    sel.appendChild(o);
  });
  sel.value = p.role;
  sel.addEventListener("change", () => changeRole(p, sel.value, sel));
  row.appendChild(sel);

  const bl = el("button", "small" + (p.approved ? " danger" : ""), p.approved ? "إيقاف" : "تفعيل");
  bl.addEventListener("click", () => toggleBlock(p));
  row.appendChild(bl);

  const del = el("button", "small danger", "حذف");
  del.addEventListener("click", () => deletePerson(p));
  row.appendChild(del);
  c.appendChild(row);
  return c;
}
function peopleDate(v) {
  if (!v) return "—";
  try { return new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium", timeStyle: "short" }).format(new Date(v)); }
  catch (_) { return v; }
}
async function renderPeople(reload) {
  if (!isAdmin()) return;
  const box = $("people-box");
  if (reload) {
    showLoading(true);
    const { data, error } = await sb.from("profiles")
      .select("id,first_name,username,role,approved,created_at,bot_ok,courses_chosen")
      .order("created_at", { ascending: false });
    showLoading(false);
    if (error) { say("تعذّر تحميل الحسابات", true); return; }
    state.people = data;
    state.peopleQuery = "";
    state.peopleLimit = 50;
    state.peopleRoleFilter = "all";
    state.peopleStatusFilter = "all";
  }
  box.replaceChildren();

  const top = el("div", "people-head");
  const title = el("div");
  title.appendChild(el("h2", "", "المستخدمون"));
  title.appendChild(el("p", "meta", isFull()
    ? "إدارة المستخدمين — Full Admin يملك التعديل، الإيقاف، التفعيل والحذف."
    : "إدارة المستخدمين — Admin في وضع قراءة فقط وفق مصفوفة الصلاحيات."));
  top.appendChild(title);

  const back = el("button", "small", "رجوع");
  back.addEventListener("click", () => setView("app"));
  top.appendChild(back);
  box.appendChild(top);

  const stats = el("div", "people-stats");
  const total = state.people.length;
  const students = state.people.filter((p) => p.role === "student").length;
  const admins = state.people.filter((p) => p.role === "admin").length;
  const fulls = state.people.filter((p) => p.role === "full_admin").length;
  const blocked = state.people.filter((p) => !p.approved).length;
  const notifyOff = state.people.filter((p) => p.bot_ok === false).length;
  [[total,"إجمالي الحسابات"],[students,"طلاب"],[admins,"Admin"],[fulls,"Full Admin"],[blocked,"موقوف"],[notifyOff,"إشعارات متوقفة"]].forEach(([n,l])=>{
    const x=el("div","people-stat"); x.appendChild(el("strong","",String(n))); x.appendChild(el("span","",l)); stats.appendChild(x);
  });
  box.appendChild(stats);

  const filters = el("div", "people-filters");
  const q = el("input");
  q.type = "search";
  q.placeholder = "بحث بالاسم أو اليوزر";
  q.value = state.peopleQuery || "";
  filters.appendChild(q);
  const role = el("select");
  [["all","كل الأدوار"],["student","Student"],["admin","Admin"],["full_admin","Full Admin"]].forEach(([v,l])=>{const o=el("option","",l);o.value=v;role.appendChild(o);});
  role.value = state.peopleRoleFilter || "all";
  filters.appendChild(role);
  const status = el("select");
  [["all","كل الحالات"],["active","مفعّل"],["blocked","موقوف"],["notify_off","إشعارات متوقفة"]].forEach(([v,l])=>{const o=el("option","",l);o.value=v;status.appendChild(o);});
  status.value = state.peopleStatusFilter || "all";
  filters.appendChild(status);
  const sort = el("select");
  [["newest","الأحدث أولًا"],["oldest","الأقدم أولًا"],["name","الاسم أبجديًا"],["role","الدور"]].forEach(([v,l])=>{const o=el("option","",l);o.value=v;sort.appendChild(o);});
  sort.value = state.peopleSort || "newest";
  filters.appendChild(sort);
  const refresh = el("button", "small", "تحديث");
  refresh.addEventListener("click", () => renderPeople(true));
  filters.appendChild(refresh);
  box.appendChild(filters);

  const info = el("p", "meta");
  box.appendChild(info);
  const res = el("div", "people-grid");
  box.appendChild(res);
  const paint = () => {
    res.replaceChildren();
    const s = (state.peopleQuery || "").trim().toLowerCase().replace(/^@/, "");
    const all = state.people.filter((p) => {
      const textMatch = !s || (p.first_name || "").toLowerCase().includes(s) || (p.username || "").toLowerCase().includes(s);
      const roleMatch = (state.peopleRoleFilter || "all") === "all" || p.role === state.peopleRoleFilter;
      const statusMatch = (state.peopleStatusFilter || "all") === "all"
        || (state.peopleStatusFilter === "active" && p.approved)
        || (state.peopleStatusFilter === "blocked" && !p.approved)
        || (state.peopleStatusFilter === "notify_off" && p.bot_ok === false);
      return textMatch && roleMatch && statusMatch;
    });
    const mode = state.peopleSort || "newest";
    all.sort((a,b) => {
      if (mode === "oldest") return String(a.created_at||"").localeCompare(String(b.created_at||""));
      if (mode === "name") return (a.first_name||"").localeCompare(b.first_name||"","ar");
      if (mode === "role") return (roleRank[a.role]??3)-(roleRank[b.role]??3) || (a.first_name||"").localeCompare(b.first_name||"","ar");
      return String(b.created_at||"").localeCompare(String(a.created_at||""));
    });
    const shown = all.slice(0, state.peopleLimit || 50);
    info.textContent = "عرض " + shown.length + " من " + all.length + " حساب";
    shown.forEach((p) => res.appendChild(personCard(p)));
    if (all.length > shown.length) {
      const more = el("button", "", "عرض المزيد");
      more.addEventListener("click", () => { state.peopleLimit += 50; paint(); });
      res.appendChild(more);
    }
    if (!all.length) res.appendChild(el("p", "center", "مفيش حسابات مطابقة للبحث الحالي."));
  };
  q.addEventListener("input", () => { state.peopleQuery = q.value; state.peopleLimit = 50; paint(); });
  role.addEventListener("change", () => { state.peopleRoleFilter = role.value; state.peopleLimit = 50; paint(); });
  status.addEventListener("change", () => { state.peopleStatusFilter = status.value; state.peopleLimit = 50; paint(); });
  sort.addEventListener("change", () => { state.peopleSort = sort.value; state.peopleLimit = 50; paint(); });
  paint();
}
/* السجل (للأدمنز) */
const actLabels = {
  add: "إضافة", edit: "تعديل", delete: "حذف (إلى السلة)",
  restore: "استرجاع", purge: "حذف نهائي",
  role: "تغيير الدور", block: "إيقاف حساب", unblock: "تفعيل حساب",
  clear_log: "مسح السجل",
};
async function renderLog() {
  if (!isAdmin()) return;
  const box = $("log-box");
  box.replaceChildren();
  showLoading(true);
  const [l, p] = await Promise.all([
    sb.from("audit_log").select("id,actor,action,details,created_at")
      .order("created_at", { ascending: false }).limit(state.logLimit),
    sb.from("profiles").select("id,first_name,username"),
  ]);
  showLoading(false);
  if (l.error || p.error) { say("تعذّر تحميل السجل", true); return; }
  const names = {};
  p.data.forEach((x) => { names[x.id] = x.first_name || (x.username ? "@" + x.username : "—"); });
  const top = el("div", "row");
  top.appendChild(el("h3", "", "السجل"));
  const back = el("button", "small", "رجوع");
  back.addEventListener("click", () => setView("app"));
  top.appendChild(back);
  if (isFull() && l.data.length) {
    const clr = el("button", "small danger", "مسح السجل");
    clr.addEventListener("click", async () => {
      if (!confirm("مسح كل السجل؟ لا يمكن التراجع، وسيبقى سطر واحد يوضح من قام بالمسح.")) return;
      const { error } = await sb.rpc("clear_audit_log");
      if (error) { say(rpcMsg(error)); return; }
      say("تم مسح السجل");
      renderLog();
    });
    top.appendChild(clr);
  }
  box.appendChild(top);
  if (!l.data.length) box.appendChild(el("p", "center", "لا توجد سجلات بعد"));
  l.data.forEach((r) => {
    const c = el("div", "card");
    c.appendChild(el("h3", "", (r.details && r.details.title) || "—"));
    const who = r.actor ? (names[r.actor] || "—") : "النظام";
    const to = r.details && r.details.to ? " → " + (roleLabels[r.details.to] || r.details.to) : "";
    c.appendChild(el("p", "meta", (actLabels[r.action] || r.action) + to + " · " + who));
    c.appendChild(el("p", "meta", logFmt.format(new Date(r.created_at))));
    box.appendChild(c);
  });
  if (l.data.length >= state.logLimit) {
    const more = el("button", "", "عرض المزيد");
    more.addEventListener("click", () => { state.logLimit += 100; renderLog(); });
    box.appendChild(more);
  }
}
/* التقدّم والحذف */
async function save(itemId, done, submitted) {
  if (isGuest()) { say("تسجيل الدخول مطلوب لحفظ التقدّم"); return; }
  const { error } = await sb.from("progress").upsert(
    { user_id: state.userId, item_id: itemId, done, submitted, updated_at: new Date().toISOString() },
    { onConflict: "user_id,item_id" }
  );
  if (error) { say("تعذّر الحفظ"); return; }
  state.progress[itemId] = { item_id: itemId, done, submitted };
  say("");
  render();
}
async function setDeleted(id, val) {
  if (!isAdmin()) { say("غير مسموح"); return; }
  if (val && !confirm("تأكيد الحذف؟ يمكن استرجاعه من سلة المحذوفات.")) return;
  const { error } = await sb.from("items")
    .update({ deleted_at: val ? new Date().toISOString() : null }).eq("id", id);
  if (error) { say("تعذّر التنفيذ"); return; }
  say(val ? "تم الحذف" : "تم الاسترجاع");
  await loadData();
}
async function purge(id) {
  if (!isFull()) { say("غير مسموح"); return; }
  if (!confirm("حذف نهائي؟ لا يمكن التراجع، وستُمسح علامات الإنجاز الخاصة بهذا العنصر عند الجميع.")) return;
  const it = state.items.find((x) => x.id === id);
  const { data, error } = await sb.from("items").delete().eq("id", id).select("id");
  if (error || !data || !data.length) { say("تعذّر الحذف النهائي"); return; }
  if (it && it.attachment_path) await removeAttachmentFiles([it.attachment_path]);
  say("تم الحذف النهائي");
  await loadData();
}
async function emptyTrash(ids) {
  if (!isFull()) { say("غير مسموح"); return; }
  if (!ids.length) return;
  if (!confirm("تفريغ السلة؟ سيتم حذف " + ids.length + " عنصر نهائيًا ولا يمكن التراجع.")) return;
  const paths = state.items.filter((x) => ids.includes(x.id) && x.attachment_path).map((x) => x.attachment_path);
  const { data, error } = await sb.from("items").delete().in("id", ids).select("id");
  if (error || !data) { say("تعذّر تفريغ السلة"); return; }
  if (paths.length) await removeAttachmentFiles(paths);
  say("تم حذف " + data.length + " عنصر نهائيًا");
  await loadData();
}
/* العناصر الشخصية */
async function setPersonalDone(p, v) {
  const { error } = await sb.from("personal_items")
    .update({ done: v, updated_at: new Date().toISOString() }).eq("id", p.id);
  if (error) { say("تعذّر الحفظ"); render(); return; }
  p.done = v;
  say("");
  render();
}
async function deletePersonal(p) {
  if (!confirm("حذف هذا العنصر الشخصي نهائيًا؟")) return;
  const { error } = await sb.from("personal_items").delete().eq("id", p.id);
  if (error) { say("تعذّر الحذف"); return; }
  say("تم الحذف");
  await loadData();
}
function buildPersonalForm(p) {
  const c = el("div", "card");
  c.appendChild(el("h3", "", p ? "تعديل عنصر شخصي" : "عنصر شخصي جديد"));
  const title = el("input");
  title.type = "text";
  title.maxLength = 200;
  title.value = p ? p.title : "";
  c.appendChild(field("العنوان", title));
  const body = el("textarea");
  body.rows = 3;
  body.maxLength = 2000;
  body.value = p && p.body ? p.body : "";
  c.appendChild(field("التفاصيل", body));
  const dl = el("input");
  dl.type = "datetime-local";
  dl.value = p && p.deadline ? toLocalInput(p.deadline) : "";
  c.appendChild(field("معاد التسليم (اختياري)", dl));
  const row = el("div", "row");
  const ok = el("button", "", "حفظ");
  const cancel = el("button", "", "إلغاء");
  cancel.addEventListener("click", () => { state.pform = null; say(""); render(); });
  ok.addEventListener("click", async () => {
    const data = {
      title: title.value.trim(),
      body: body.value.trim() || null,
      deadline: dl.value ? localToISO(dl.value) : null,
    };
    if (!data.title) { say("العنوان مطلوب"); return; }
    ok.disabled = true;
    const { error } = p
      ? await sb.from("personal_items").update({ ...data, updated_at: new Date().toISOString() }).eq("id", p.id)
      : await sb.from("personal_items").insert({ ...data, user_id: state.userId });
    ok.disabled = false;
    if (error) { say("تعذّر الحفظ"); return; }
    state.pform = null;
    say("تم الحفظ");
    await loadData();
  });
  row.appendChild(ok);
  row.appendChild(cancel);
  c.appendChild(row);
  return c;
}
function personalCard(p) {
  const c = el("div", "card" + (p.done ? " doneitem" : ""));
  c.appendChild(el("h3", "", p.title));
  c.appendChild(el("p", "meta", "شخصي"));
  if (p.body) c.appendChild(el("p", "body", p.body));
  if (p.deadline) c.appendChild(el("p", "meta", "معاد التسليم: " + fmt(p.deadline)));
  const row = el("div");
  row.appendChild(check("خلّصت", p.done, (v) => setPersonalDone(p, v)));
  c.appendChild(row);
  const act = el("div", "row");
  const e = el("button", "small", "تعديل");
  e.addEventListener("click", () => { state.pform = { id: p.id }; state.form = null; say(""); render(); });
  const d = el("button", "small danger", "حذف");
  d.addEventListener("click", () => deletePersonal(p));
  act.appendChild(e);
  act.appendChild(d);
  c.appendChild(act);
  return c;
}
/* نموذج الإضافة والتعديل */

function buildCustomForm(sec, it) {
  if (!isAdmin()) return el("div", "card", "غير مسموح");
  const c = el("div", "card custom-item-builder");
  c.appendChild(el("h3", "", it ? "تعديل عنصر حر" : "إضافة عنصر حر"));
  c.appendChild(el("p", "meta", "اختار الحقول اللي محتاجها للعنصر ده فقط. مفيش قالب ثابت للقسم."));

  const defs = [
    ["title", "العنوان"],
    ["body", "التفاصيل / النص"],
    ["url", "رابط خارجي"],
    ["attachment", "ملف / صورة / فيديو / PDF"],
    ["deadline", "تاريخ / موعد"],
    ["course", "المادة"]
  ];
  const initial = {
    title: !!(it && it.title),
    body: !!(it && it.body),
    url: !!(it && it.url),
    attachment: !!(it && it.attachment_kind),
    deadline: !!(it && it.deadline),
    course: !!(it && it.course_id != null)
  };
  const savedOrder = Array.isArray(it && it.field_order) ? it.field_order : [];
  const allKeys = defs.map(([key]) => key);
  const selected = {...initial};
  if (savedOrder.length) {
    allKeys.forEach((key) => { selected[key] = savedOrder.includes(key); });
  }
  const fieldOrder = [];
  const seenOrder = new Set();
  savedOrder.forEach((key) => {
    if (allKeys.includes(key) && selected[key] && !seenOrder.has(key)) {
      seenOrder.add(key);
      fieldOrder.push(key);
    }
  });
  allKeys.forEach((key) => {
    if (selected[key] && !seenOrder.has(key)) {
      seenOrder.add(key);
      fieldOrder.push(key);
    }
  });
  const fieldsBox = el("div", "custom-field-picker");
  fieldsBox.appendChild(el("div", "custom-field-picker-title", "اختيار وترتيب الحقول"));
  fieldsBox.appendChild(el("p", "meta", "اختار الحقول اللي تحتاجها، وبعدها رتّبها بالأسهم. الترتيب ينعكس في المعاينة وعرض الطالب."));
  const rowsBox = el("div", "custom-field-rows");
  fieldsBox.appendChild(rowsBox);
  const inputs = {};
  const rows = {};
  function redrawFieldRows(){
    rowsBox.replaceChildren();
    fieldOrder.forEach((key, position) => {
      const row = rows[key];
      if (!row || !selected[key]) return;
      row.hidden = false;
      row.querySelector(".custom-field-up").disabled = position === 0;
      row.querySelector(".custom-field-down").disabled = position === fieldOrder.length - 1;
      rowsBox.appendChild(row);
    });
  }
  defs.forEach(([key,label])=>{
    const row=el("div","custom-field-row");
    const main=el("label","custom-field-option");
    const cb=el("input"); cb.type="checkbox"; cb.checked=selected[key];
    cb.addEventListener("change",()=>{
      selected[key]=cb.checked;
      const i=fieldOrder.indexOf(key);
      if(cb.checked && i===-1) fieldOrder.push(key);
      if(!cb.checked && i!==-1) fieldOrder.splice(i,1);
      redrawFieldRows();
      syncFields();
      refreshPreview();
    });
    main.appendChild(cb); main.appendChild(el("span","",label));
    const controls=el("div","custom-field-order");
    const up=el("button","small custom-field-up","↑");
    const down=el("button","small custom-field-down","↓");
    up.type="button"; down.type="button";
    up.title = "نقل الحقل لأعلى";
    down.title = "نقل الحقل لأسفل";
    up.setAttribute("aria-label", "نقل الحقل لأعلى");
    down.setAttribute("aria-label", "نقل الحقل لأسفل");
    up.addEventListener("click",()=>{const i=fieldOrder.indexOf(key);if(i>0){[fieldOrder[i-1],fieldOrder[i]]=[fieldOrder[i],fieldOrder[i-1]];redrawFieldRows();refreshPreview();}});
    down.addEventListener("click",()=>{const i=fieldOrder.indexOf(key);if(i<fieldOrder.length-1){[fieldOrder[i+1],fieldOrder[i]]=[fieldOrder[i],fieldOrder[i+1]];redrawFieldRows();refreshPreview();}});
    controls.append(up,down); row.append(main,controls); inputs[key]=cb; rows[key]=row;
  });
  redrawFieldRows();
  c.appendChild(fieldsBox);

  const title=el("input"); title.type="text"; title.value=it&&it.title?it.title:""; title.placeholder="عنوان اختياري";
  const titleWrap=field("العنوان",title); c.appendChild(titleWrap);
  const body=el("textarea"); body.rows=5; body.value=it&&it.body?it.body:""; body.placeholder="اكتب النص أو التفاصيل هنا";
  const bodyWrap=field("التفاصيل",body); c.appendChild(bodyWrap);
  const url=el("input"); url.type="url"; url.dir="ltr"; url.value=it&&it.url?it.url:""; url.placeholder="https://...";
  const urlWrap=field("الرابط",url); c.appendChild(urlWrap);

  let attFile=null, removeAtt=false;
  const attWrap=el("div","custom-field-content");
  if(it&&it.attachment_kind){
    const cur=el("div","row"); cur.appendChild(el("span","meta",it.attachment_kind==="file"?"مرفق حالي: "+(it.attachment_name||"ملف"):"مرفق حالي: رابط خارجي"));
    const rm=el("button","small danger","إزالة المرفق"); rm.addEventListener("click",()=>{removeAtt=true;rm.disabled=true;cur.appendChild(el("span","meta"," — هيتشال عند الحفظ"));}); cur.appendChild(rm); attWrap.appendChild(cur);
  }
  const fi=el("input"); fi.type="file"; fi.accept="*/*"; fi.addEventListener("change",()=>{attFile=fi.files[0]||null;});
  attWrap.appendChild(field("رفع ملف",fi));
  const alink=el("input"); alink.type="url"; alink.dir="ltr"; alink.placeholder="https://drive.google.com/...";
  attWrap.appendChild(field("أو رابط ملف خارجي",alink)); c.appendChild(attWrap);

  const dl=el("input"); dl.type="datetime-local"; if(it&&it.deadline) dl.value=toLocalInput(it.deadline); c.appendChild(field("التاريخ والوقت",dl));
  const csel=el("select"); const empty=el("option","","بدون مادة"); empty.value=""; csel.appendChild(empty);
  state.courses.filter(x=>x.is_active||(it&&it.course_id===x.id)).forEach(x=>{const o=el("option","",x.name);o.value=String(x.id);csel.appendChild(o);});
  csel.value=it&&it.course_id!=null?String(it.course_id):""; c.appendChild(field("المادة",csel));

  function syncFields(){
    titleWrap.hidden=!selected.title; bodyWrap.hidden=!selected.body; urlWrap.hidden=!selected.url; attWrap.hidden=!selected.attachment;
    dl.parentElement.hidden=!selected.deadline; csel.parentElement.hidden=!selected.course;
  }
  syncFields();

  const preview = el("section", "custom-live-preview");
  preview.appendChild(el("div", "custom-live-preview-title", "معاينة الطالب"));
  const previewCard = el("div", "card custom-preview-card");
  preview.appendChild(previewCard);
  c.appendChild(preview);

  function refreshPreview(){
    previewCard.replaceChildren();
    const t = selected.title ? title.value.trim() : "";
    const b = selected.body ? body.value.trim() : "";
    const u = selected.url ? safeUrl(url.value.trim()) : null;
    const d = selected.deadline && dl.value ? localToISO(dl.value) : null;
    const course = selected.course && csel.value ? state.courses.find(x => String(x.id) === String(csel.value)) : null;
    fieldOrder.forEach((key)=>{
      if (key === "title" && t) previewCard.appendChild(el("h3", "", t));
      if (key === "course" && course) previewCard.appendChild(el("p", "meta", course.name));
      if (key === "body" && b) previewCard.appendChild(el("p", "body", b));
      if (key === "deadline" && d) previewCard.appendChild(el("p", "meta", "الموعد: " + fmt(d)));
      if (key === "url" && u) { const a=el("a", "btn", "🔗 فتح الرابط"); a.href=u; a.target="_blank"; a.rel="noopener noreferrer"; previewCard.appendChild(a); }
      if (key === "attachment" && selected.attachment) {
        const chosen = attFile || (alink.value.trim() ? {name:"رابط ملف خارجي"} : null);
        if (chosen) previewCard.appendChild(el("p", "meta", "📎 " + (chosen.name || "مرفق")));
        else if (it && it.attachment_kind && !removeAtt) previewCard.appendChild(el("p", "meta", "📎 " + (it.attachment_name || "مرفق موجود")));
      }
    });
    if (!previewCard.childNodes.length) previewCard.appendChild(el("p", "meta", "اختار حقلًا واكتب محتواه عشان تشوف المعاينة."));
  }
  [title, body, url, dl, csel].forEach(node => node.addEventListener("input", refreshPreview));
  csel.addEventListener("change", refreshPreview);
  alink.addEventListener("input", refreshPreview);
  fi.addEventListener("change", refreshPreview);
  refreshPreview();

  const row=el("div","row"); const ok=el("button","","حفظ"); const cancel=el("button","small","إلغاء");
  cancel.addEventListener("click",()=>{state.form=null;say("");render();});
  ok.addEventListener("click",async()=>{
    if(!Object.values(selected).some(Boolean)){say("اختار حقل واحد على الأقل");return;}
    const data={title:null,body:null,url:null,deadline:null,deadline_has_time:null,course_id:null};
    const normalizedOrder = fieldOrder.filter((key) => selected[key]);
    if(selected.title){data.title=title.value.trim()||null; if(!data.title) return say("اكتب العنوان أو ألغِ حقل العنوان");}
    if(selected.body) data.body=body.value.trim()||null;
    if(selected.url){const raw=url.value.trim(); if(raw){const u=safeUrl(raw);if(!u)return say("الرابط غير صالح");data.url=u;} else return say("اكتب الرابط أو ألغِ حقل الرابط");}
    if(selected.deadline){if(!dl.value)return say("التاريخ مطلوب");data.deadline=localToISO(dl.value);data.deadline_has_time=true;}
    if(selected.course) data.course_id=csel.value?Number(csel.value):null;
    let oldPath=it&&it.attachment_path?it.attachment_path:null;
    const linkVal=alink.value.trim();
    if(selected.attachment){
      if(attFile&&linkVal)return say("اختار ملف أو رابط ملف، مش الاتنين");
      ok.disabled=true;
      if(attFile) attFile=await shrinkImage(attFile);
      if(attFile&&attFile.size>MAX_ATTACH){ok.disabled=false;return say("الملف أكبر من 10 ميجا");}
      if(attFile){const up=await uploadAttachment(sec.id,attFile);if(up.error){ok.disabled=false;return say("تعذّر رفع الملف");}Object.assign(data,up.data);}
      else if(linkVal){const u=safeUrl(linkVal);if(!u){ok.disabled=false;return say("رابط الملف غير صالح");}Object.assign(data,{attachment_kind:"link",attachment_url:u,attachment_path:null,attachment_name:null,attachment_mime:null,attachment_size:null});}
      else if(removeAtt) Object.assign(data,{attachment_kind:null,attachment_url:null,attachment_path:null,attachment_name:null,attachment_mime:null,attachment_size:null});
    } else if(it&&it.attachment_kind){
      Object.assign(data,{attachment_kind:null,attachment_url:null,attachment_path:null,attachment_name:null,attachment_mime:null,attachment_size:null});
    }
    if (itemFieldOrderSupported) data.field_order = normalizedOrder;
    ok.disabled=true;
    let res=it?await sb.from("items").update(data).eq("id",it.id):await sb.from("items").insert({...data,section_id:sec.id});
    if (res.error && itemFieldOrderSupported && /field_order|column/i.test(res.error.message || "")) {
      const fallbackData = {...data}; delete fallbackData.field_order;
      res = it ? await sb.from("items").update(fallbackData).eq("id",it.id) : await sb.from("items").insert({...fallbackData,section_id:sec.id});
    }
    ok.disabled=false;
    if(res.error){say("تعذّر الحفظ");return;}
    if(oldPath&&(attFile||linkVal||removeAtt||!selected.attachment)) await removeAttachmentFiles([oldPath]);
    state.form=null; await loadData(); say("تم حفظ العنصر"); render();
  });
  row.append(ok,cancel); c.appendChild(row); return c;
}

function buildForm(sec, it) {
  if (sec.kind === "custom") return buildCustomForm(sec, it);
  if (!isAdmin()) return el("div", "card", "غير مسموح");
  const c = el("div", "card");
  c.appendChild(el("h3", "", it ? "تعديل" : "إضافة"));
  const title = el("input");
  title.type = "text";
  title.value = it ? it.title : "";
  c.appendChild(field("العنوان", title));
  const body = el("textarea");
  body.rows = 4;
  body.value = it && it.body ? it.body : "";
  c.appendChild(field("التفاصيل", body));
  let csel = null;
  if (sec.kind !== "newsletter" && sec.kind !== "custom") {
    csel = el("select");
    const first = el("option", "", sec.kind === "news" ? "أخبار عامة" : "— اختيار المادة —");
    first.value = "";
    csel.appendChild(first);
    state.courses
      .filter((x) => x.is_active || (it && it.course_id === x.id))
      .forEach((x) => {
        const o = el("option", "", x.name);
        o.value = String(x.id);
        csel.appendChild(o);
      });
    csel.value = it && it.course_id != null ? String(it.course_id) : "";
    c.appendChild(field(sec.kind === "news" ? "التصنيف" : "المادة", csel));
  }
  let url = null, dl = null, hasTime = true, scheduleDateMode = null;
  if (sec.kind === "links" || sec.kind === "newsletter") {
    url = el("input");
    url.type = "url";
    url.dir = "ltr";
    url.value = it && it.url ? it.url : "";
    url.placeholder = sec.kind === "newsletter" ? "https://.../newsletter.pdf" : "https://...";
    c.appendChild(field(sec.kind === "newsletter" ? "رابط ملف الـPDF" : "رابط اختياري", url));
  }
  if (sec.kind === "tasks" || sec.kind === "schedule") {
    if (sec.kind === "schedule") {
      scheduleDateMode = it && it.deadline ? (it.deadline_has_time !== false ? "datetime" : "date") : "none";
      const mode = el("select");
      [["datetime","تاريخ ووقت"],["date","تاريخ فقط"],["none","بدون موعد — يُحدد لاحقًا"]].forEach(([v,label])=>{
        const o=el("option","",label); o.value=v; mode.appendChild(o);
      });
      mode.value=scheduleDateMode;
      c.appendChild(field("الموعد",mode));
      dl = el("input");
      dl.type = scheduleDateMode === "datetime" ? "datetime-local" : "date";
      if (it && it.deadline) dl.value = scheduleDateMode === "datetime" ? toLocalInput(it.deadline) : toLocalInput(it.deadline).slice(0,10);
      const dateField = field("التاريخ", dl);
      dateField.hidden = scheduleDateMode === "none";
      c.appendChild(dateField);
      mode.addEventListener("change",()=>{
        scheduleDateMode=mode.value;
        dateField.hidden=scheduleDateMode === "none";
        dl.type=scheduleDateMode === "datetime" ? "datetime-local" : "date";
        const cur=dl.value;
        dl.value=cur ? (scheduleDateMode === "datetime" ? (cur.length===10 ? cur+"T23:59" : cur) : cur.slice(0,10)) : "";
      });
    } else {
      hasTime = it ? it.deadline_has_time !== false : true;
      dl = el("input");
      dl.type = hasTime ? "datetime-local" : "date";
      if (it && it.deadline) {
        dl.value = hasTime ? toLocalInput(it.deadline) : toLocalInput(it.deadline).slice(0, 10);
      }
      c.appendChild(field("معاد التسليم", dl));
      c.appendChild(check("تحديد ساعة معاد التسليم", hasTime, (v) => {
        hasTime = v;
        const cur = dl.value;
        dl.type = hasTime ? "datetime-local" : "date";
        dl.value = cur ? (hasTime ? (cur.length === 10 ? cur + "T23:59" : cur) : cur.slice(0, 10)) : "";
      }));
    }
  }
  let attFile = null, removeAtt = false;
  if (sec.kind !== "links") {
    if (it && it.attachment_kind) {
      const cur = el("div", "row");
      cur.appendChild(el("span", "meta", it.attachment_kind === "file"
        ? "مرفق حالي: " + (it.attachment_name || "ملف") + (it.attachment_size ? " (" + humanSize(it.attachment_size) + ")" : "")
        : "مرفق حالي: رابط خارجي"));
      const rm = el("button", "small danger", "إزالة المرفق");
      rm.addEventListener("click", () => { removeAtt = true; rm.disabled = true; cur.appendChild(el("span", "meta", " — هتتشال عند الحفظ")); });
      cur.appendChild(rm);
      c.appendChild(cur);
    }
    const fi = el("input");
    fi.type = "file";
    c.appendChild(field("إرفاق ملف (صورة / فيديو / PDF / أي نوع). يُفضَّل أقل من 5 ميجا، والحد الأقصى 10 ميجا", fi));
    fi.addEventListener("change", () => { attFile = fi.files[0] || null; });
    const alink = el("input");
    alink.type = "url";
    alink.dir = "ltr";
    alink.placeholder = "https://drive.google.com/...";
    c.appendChild(field("أو رابط خارجي (للملفات الكبيرة، مثل Drive)", alink));
    var attLinkInput = alink;
  }
  const row = el("div", "row");
  const ok = el("button", "", "حفظ");
  const cancel = el("button", "", "إلغاء");
  cancel.addEventListener("click", () => { state.form = null; say(""); render(); });
  ok.addEventListener("click", async () => {
    const data = { title: title.value.trim(), body: body.value.trim() || null };
    if (!data.title) { say("العنوان مطلوب"); return; }
    if (sec.kind !== "news" && sec.kind !== "newsletter" && sec.kind !== "custom" && !csel.value) { say("المادة مطلوبة"); return; }
    if (csel) data.course_id = csel.value ? Number(csel.value) : null;
    if (dl) {
      if (sec.kind === "schedule") {
        if (scheduleDateMode === "none") {
          data.deadline = null;
          data.deadline_has_time = null;
        } else {
          if (!dl.value) { say("التاريخ مطلوب، أو اختر بدون موعد"); return; }
          data.deadline = localToISO(scheduleDateMode === "datetime" ? dl.value : dl.value + "T23:59");
          data.deadline_has_time = scheduleDateMode === "datetime";
        }
      } else {
        if (!dl.value) { say("معاد التسليم مطلوب"); return; }
        data.deadline = localToISO(hasTime ? dl.value : dl.value + "T23:59");
        data.deadline_has_time = hasTime;
      }
    }
    if (url) {
      const u = safeUrl(url.value.trim());
      if (!u) { say("الرابط غير صالح"); return; }
      data.url = u;
    }
    const linkVal = attLinkInput ? attLinkInput.value.trim() : "";
    if (attFile && linkVal) { say("الاختيار: رفع ملف أو رابط خارجي، وليس الاثنين معًا"); return; }
    let oldPath = it && it.attachment_path ? it.attachment_path : null;
    ok.disabled = true;
    if (attFile) attFile = await shrinkImage(attFile);
    if (attFile && attFile.size > MAX_ATTACH) { ok.disabled = false; say("الملف أكبر من 10 ميجا، يُرجى استخدام رابط خارجي"); return; }
    if (attFile && attFile.size > WARN_ATTACH
        && !confirm("حجم الملف " + humanSize(attFile.size) + ". الملفات الكبيرة تستهلك من حصة الموقع المجانية عند كل فتح. الأفضل استخدام رابط خارجي (Drive). المتابعة بالرفع؟")) {
      ok.disabled = false;
      return;
    }
    if (attFile) {
      const up = await uploadAttachment(sec.id, attFile);
      if (up.error) { ok.disabled = false; say("تعذّر رفع الملف"); return; }
      Object.assign(data, up.data);
    } else if (linkVal) {
      const u = safeUrl(linkVal);
      if (!u) { ok.disabled = false; say("رابط المرفق غير صالح"); return; }
      data.attachment_kind = "link"; data.attachment_url = u; data.attachment_path = null;
      data.attachment_name = null; data.attachment_mime = null; data.attachment_size = null;
    } else if (removeAtt) {
      data.attachment_kind = null; data.attachment_url = null; data.attachment_path = null;
      data.attachment_name = null; data.attachment_mime = null; data.attachment_size = null;
    } else {
      oldPath = null; // مفيش تغيير، ما نمسحش حاجة
    }
    const { error } = it
      ? await sb.from("items").update(data).eq("id", it.id)
      : await sb.from("items").insert({ ...data, section_id: sec.id });
    ok.disabled = false;
    if (error) { say("تعذّر الحفظ"); return; }
    if (oldPath && (attFile || linkVal || removeAtt)) await removeAttachmentFiles([oldPath]);
    state.form = null;
    say("تم الحفظ");
    await loadData();
  });
  row.appendChild(ok);
  row.appendChild(cancel);
  c.appendChild(row);
  return c;
}
/* العرض */
const isDone = (it) => { const p = state.progress[it.id]; return !!(p && p.done && p.submitted); };
function visible(sec, it) {
  if (sec.kind === "tasks" && !isAdmin() && !state.mine.has(it.course_id)) return false;
  if (state.filter === "all") return true;
  if (state.filter === "general") return it.course_id == null;
  return it.course_id === state.filter;
}
function customFieldOrder(it) {
  const defs = ["title","course","body","attachment","deadline","url"];
  const hasValue = {
    title: !!it?.title,
    course: it?.course_id != null,
    body: !!it?.body,
    attachment: !!it?.attachment_kind,
    deadline: !!it?.deadline,
    url: !!it?.url
  };
  const seen = new Set();
  const saved = Array.isArray(it?.field_order) ? it.field_order : [];
  const ordered = [];
  for (const key of saved) {
    if (defs.includes(key) && hasValue[key] && !seen.has(key)) {
      seen.add(key);
      ordered.push(key);
    }
  }
  defs.forEach((key) => {
    if (hasValue[key] && !seen.has(key)) {
      seen.add(key);
      ordered.push(key);
    }
  });
  return ordered;
}

function appendCustomAttachment(c, it) {
  if (!it.attachment_kind) return;
  const wrap = el("div");
  const mime = it.attachment_mime || "";
  if (it.attachment_kind === "file" && mime.startsWith("image/")) {
    const img = el("img"); img.loading="lazy"; img.decoding="async"; img.src=it.attachment_url; img.style.maxWidth="100%"; img.style.borderRadius="8px"; wrap.appendChild(img);
  } else if (it.attachment_kind === "file" && mime.startsWith("video/")) {
    const v=el("video"); v.preload="none"; v.setAttribute("playsinline",""); v.src=it.attachment_url; v.controls=true; v.style.maxWidth="100%"; wrap.appendChild(v);
  } else if (it.attachment_kind === "file" && mime === "application/pdf") {
    const show=el("button","","📄 عرض الملف هنا"); show.style.marginBottom="8px";
    show.addEventListener("click",()=>{const f=el("iframe");f.src=it.attachment_url;f.style.width="100%";f.style.height="70vh";f.style.border="2px solid var(--line)";f.style.borderRadius="8px";show.replaceWith(f);});
    wrap.appendChild(show);
  }
  const box=el("div","row");
  if(it.attachment_kind === "link") {
    const a=el("a","btn","🔗 فتح المرفق (رابط خارجي)"); a.href=it.attachment_url; a.target="_blank"; a.rel="noopener noreferrer"; box.appendChild(a);
  } else {
    const open=el("a","btn","↗️ فتح في نافذة جديدة"); open.href=it.attachment_url; open.target="_blank"; open.rel="noopener noreferrer"; box.appendChild(open);
    const dl=el("a","btn","⬇️ تحميل"+(it.attachment_size?" ("+humanSize(it.attachment_size)+")":"")); dl.href=it.attachment_url+(it.attachment_url.includes("?")?"&":"?")+"download="+encodeURIComponent(it.attachment_name||""); dl.rel="noopener noreferrer"; box.appendChild(dl);
  }
  wrap.appendChild(box); c.appendChild(wrap);
}

function card(sec, it) {
  const c = el("div", "card" + (sec.kind === "tasks" && !it.deleted_at && isDone(it) ? " doneitem" : ""));
  if (sec.kind === "custom") {
    const cn = it.course_id != null ? courseName(it.course_id) : "";
    customFieldOrder(it).forEach((key) => {
      if (key === "title" && it.title) c.appendChild(el("h3", "", it.title));
      if (key === "course" && cn) c.appendChild(el("p", "meta", cn));
      if (key === "body" && it.body) c.appendChild(el("p", "body", it.body));
      if (key === "deadline" && it.deadline) c.appendChild(el("p", "meta", "الموعد: " + fmt(it.deadline)));
      if (key === "url" && it.url) { const u=safeUrl(it.url); if(u){const a=el("a","btn","🔗 فتح الرابط");a.href=u;a.target="_blank";a.rel="noopener noreferrer";c.appendChild(a);} }
      if (key === "attachment") appendCustomAttachment(c,it);
    });
  } else {
    if (it.title) c.appendChild(el("h3", "", it.title));
    const cn = sec.kind === "newsletter" ? "" : (it.course_id != null ? courseName(it.course_id) : (sec.kind === "news" ? "أخبار عامة" : ""));
    if (cn) c.appendChild(el("p", "meta", cn));
    if (it.body) c.appendChild(el("p", "body", it.body));
  }
  if (sec.kind === "tasks") {
    if (it.deadline) c.appendChild(el("p", "meta", "معاد التسليم: " + fmtDeadline(it)));
    if (!it.deleted_at) {
      const pr = state.progress[it.id] || { done: false, submitted: false };
      const row = el("div");
      row.appendChild(check("خلّصت", pr.done, (v) => save(it.id, v, v ? pr.submitted : false)));
      row.appendChild(check("سلّمت", pr.submitted, (v) => save(it.id, v ? true : pr.done, v)));
      c.appendChild(row);
    }
  }
  if (sec.kind !== "links" && sec.kind !== "custom" && it.attachment_kind) {
    const wrap = el("div");
    const mime = it.attachment_mime || "";
    if (it.attachment_kind === "file" && mime.startsWith("image/")) {
      const img = el("img");
      img.loading = "lazy";
      img.decoding = "async";
      img.src = it.attachment_url;
      img.style.maxWidth = "100%";
      img.style.borderRadius = "8px";
      wrap.appendChild(img);
    } else if (it.attachment_kind === "file" && mime.startsWith("video/")) {
      const v = el("video");
      v.preload = "none";
      v.setAttribute("playsinline", "");
      v.src = it.attachment_url;
      v.controls = true;
      v.style.maxWidth = "100%";
      wrap.appendChild(v);
    } else if (it.attachment_kind === "file" && mime === "application/pdf") {
      const show = el("button", "", "📄 عرض الملف هنا");
      show.style.marginBottom = "8px";
      show.addEventListener("click", () => {
        const f = el("iframe");
        f.src = it.attachment_url;
        f.style.width = "100%";
        f.style.height = "70vh";
        f.style.border = "2px solid var(--line)";
        f.style.borderRadius = "8px";
        show.replaceWith(f);
      });
      wrap.appendChild(show);
    }
    const box = el("div", "row");
    if (it.attachment_kind === "link") {
      const a = el("a", "btn", "🔗 فتح المرفق (رابط خارجي)");
      a.href = it.attachment_url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      box.appendChild(a);
    } else {
      const open = el("a", "btn", "↗️ فتح في نافذة جديدة");
      open.href = it.attachment_url;
      open.target = "_blank";
      open.rel = "noopener noreferrer";
      box.appendChild(open);
      const dl = el("a", "btn", "⬇️ تحميل" + (it.attachment_size ? " (" + humanSize(it.attachment_size) + ")" : ""));
      dl.href = it.attachment_url + (it.attachment_url.includes("?") ? "&" : "?")
        + "download=" + encodeURIComponent(it.attachment_name || "");
      dl.rel = "noopener noreferrer";
      box.appendChild(dl);
    }
    wrap.appendChild(box);
    c.appendChild(wrap);
  }
  if (sec.kind === "links" || sec.kind === "newsletter" || sec.kind === "custom") {
    const u = it.url ? safeUrl(it.url) : null;
    if (u) {
      const a = el("a", "btn", sec.kind === "newsletter" ? "📄 فتح العدد (PDF)" : "🔗 فتح الرابط");
      a.href = u;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      c.appendChild(a);
    }
  }
  if (isAdmin()) {
    const row = el("div", "row");
    if (it.deleted_at) {
      const r = el("button", "small", "استرجاع");
      r.addEventListener("click", () => setDeleted(it.id, false));
      row.appendChild(r);
      if (isFull()) {
        const pg = el("button", "small danger", "حذف نهائي");
        pg.addEventListener("click", () => purge(it.id));
        row.appendChild(pg);
      }
    } else {
      const e = el("button", "small", "تعديل");
      e.addEventListener("click", () => { state.form = { id: it.id }; state.pform = null; say(""); render(); });
      const d = el("button", "small danger", "حذف");
      d.addEventListener("click", () => setDeleted(it.id, true));
      row.appendChild(e);
      row.appendChild(d);
    }
    c.appendChild(row);
  }
  return c;
}
function renderChips(sec) {
  const chips = $("chips");
  chips.replaceChildren();
  if (sec.kind === "newsletter") return;
  if (sec.kind === "tasks") { chips.style.overflow = "visible"; renderSectionsMenu(sec); return; }
  chips.style.overflow = "";
  const add = (label, val) => {
    const b = el("button", "chip" + (state.filter === val ? " active" : ""), label);
    b.addEventListener("click", () => { state.filter = val; render(); });
    chips.appendChild(b);
  };
  add("الكل", "all");
  if (sec.kind === "news") add("أخبار عامة", "general");
  const list = state.courses.filter((c) => c.is_active);
  list.forEach((c) => add(c.name, c.id));
}
/* قسم التكاليف: زرار (☰ الأقسام) يفتح قائمة بدل صف الأزرار الأفقي */
function renderSectionsMenu(sec) {
  const chips = $("chips");
  const items = [{ label: "الكل", val: "all" }, { label: "شخصي", val: "personal" }];
  const courseList = isAdmin()
    ? state.courses.filter((c) => c.is_active)
    : state.courses.filter((c) => c.is_active && state.mine.has(c.id));
  courseList.forEach((c) => items.push({ label: c.name, val: c.id }));
  if (!items.find((x) => x.val === state.filter)) state.filter = "all";
  const current = items.find((x) => x.val === state.filter) || items[0];
  const wrap = el("div", "menu-wrap");
  const btn = el("button", "small", "☰ الأقسام: " + current.label);
  const dd = el("div", "dropdown");
  dd.hidden = true;
  const addItem = (label, val) => {
    const b = el("button", "chip" + (state.filter === val ? " active" : ""), label);
    b.addEventListener("click", () => { state.filter = val; dd.hidden = true; render(); });
    dd.appendChild(b);
  };
  addItem("الكل", "all");
  addItem("شخصي", "personal");
  courseList.forEach((c) => addItem(c.name, c.id));
  btn.addEventListener("click", (e) => { e.stopPropagation(); dd.hidden = !dd.hidden; });
  wrap.appendChild(btn);
  wrap.appendChild(dd);
  chips.appendChild(wrap);
}
document.addEventListener("click", (e) => {
  if (!e.target.closest(".menu-wrap")) {
    document.querySelectorAll(".menu-wrap .dropdown").forEach((d) => { d.hidden = true; });
  }
});
/* نسخة احتياطية (للمالك) */
async function downloadBackup() {
  if (!isFull()) { say("غير مسموح"); return; }
  showLoading(true);
  const { data, error } = await sb.rpc("export_backup");
  showLoading(false);
  if (error || !data) { say("تعذّر إنشاء النسخة الاحتياطية"); return; }
  const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "math3-backup-" + new Date().toISOString().slice(0, 10) + ".json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  say("تم تنزيل النسخة. يُرجى حفظها في مكان خاص (Drive أو الرسائل المحفوظة)");
}
/* تنبيه الإشعارات المتوقفة */
function renderBotBanner() {
  const b = $("bot-banner");
  b.replaceChildren();
  if (state.botOk !== false) { b.hidden = true; return; }
  b.hidden = false;
  b.appendChild(el("h3", "", "الإشعارات على تيليجرام متوقفة"));
  b.appendChild(el("p", "", "لا يمكن للبوت إرسال رسائل لهذا الحساب حاليًا، لذلك لن تصل إشعارات التكاليف والأخبار. الحل: فتح البوت والضغط على Start، ثم الضغط على «إعادة المحاولة»."));
  const row = el("div", "row");
  const open = el("a", "btn", "فتح البوت");
  open.href = "https://t.me/MATHDEPARTMENT_BOT";
  open.target = "_blank";
  open.rel = "noopener noreferrer";
  const retry = el("button", "", "إعادة المحاولة");
  retry.addEventListener("click", retryBot);
  row.appendChild(open);
  row.appendChild(retry);
  b.appendChild(row);
}
async function refreshBotStatus() {
  const { data } = await sb.from("profiles").select("bot_ok").eq("id", state.userId).single();
  if (data) { state.botOk = data.bot_ok; renderBotBanner(); }
}
async function retryBot() {
  const { error } = await sb.rpc("resend_welcome");
  if (error) {
    say((error.message || "").includes("too_soon") ? "تمت المحاولة للتو، يُرجى الانتظار دقيقتين" : "تعذّر التنفيذ");
    return;
  }
  say("تم إرسال رسالة اختبار. عند وصولها على تيليجرام سيختفي هذا التنبيه بعد قليل");
  setTimeout(refreshBotStatus, 75000);
  setTimeout(refreshBotStatus, 150000);
}
/* تبييض المحاضرات: فولدر درايف ثابت لكل مادة */
function renderLinks(sec) {
  $("chips").replaceChildren();
  const list = $("list");
  list.replaceChildren();
  const courses = state.courses.filter((c) => c.is_active || (isAdmin() && c.drive_url));
  if (!courses.length) {
    list.appendChild(el("p", "center", "لا توجد مواد بعد"));
    return;
  }
  courses.forEach((c) => {
    const card = el("div", "card");
    card.appendChild(el("h3", "", c.name + (c.is_active ? "" : " (متوقفة)")));
    if (c.drive_url) {
      const a = el("a", "btn", "📁 فتح فولدر المحاضرات");
      a.href = c.drive_url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      card.appendChild(a);
    } else {
      card.appendChild(el("p", "meta", "الرابط لسه مش متاح"));
    }
    if (isAdmin()) {
      const row = el("div", "row");
      const edit = el("button", "small", c.drive_url ? "تعديل الرابط" : "إضافة رابط");
      edit.addEventListener("click", async () => {
        const url = (prompt("رابط فولدر Drive بتاع " + c.name, c.drive_url || "") || "").trim();
        if (url === "") return;
        const u = safeUrl(url);
        if (!u) { say("الرابط غير صالح"); return; }
        const { error } = await sb.from("courses").update({ drive_url: u }).eq("id", c.id);
        if (error) { say("تعذّر الحفظ"); return; }
        say("تم الحفظ");
        await loadCourses();
        render();
      });
      row.appendChild(edit);
      if (c.drive_url) {
        const rm = el("button", "small danger", "حذف الرابط");
        rm.addEventListener("click", async () => {
          if (!confirm("حذف رابط الفولدر لمادة " + c.name + "؟")) return;
          const { error } = await sb.from("courses").update({ drive_url: null }).eq("id", c.id);
          if (error) { say("تعذّر الحذف"); return; }
          say("تم الحذف");
          await loadCourses();
          render();
        });
        row.appendChild(rm);
      }
      card.appendChild(row);
    }
    list.appendChild(card);
  });
}
/* قسم الأسئلة */
function displayName(uid) { return state.qaNames[uid] || "مستخدم"; }
function myPendingAnswer(qid) {
  return state.answers.find((a) => a.question_id === qid && a.status === "pending" && a.author_id === state.userId);
}
function approvedAnswers(qid) { return state.answers.filter((a) => a.question_id === qid && a.status === "approved"); }
function pendingAnswers(qid) { return state.answers.filter((a) => a.question_id === qid && a.status === "pending"); }
function renderQA(sec) {
  $("chips").replaceChildren();
  const list = $("list");
  list.replaceChildren();
  const bar = el("div", "row");
  const add = el("button", "", state.qform ? "إلغاء السؤال" : "+ اسأل سؤال");
  add.addEventListener("click", () => { state.qform = state.qform ? null : {}; render(); });
  bar.appendChild(add);
  list.appendChild(bar);
  if (state.qform) {
    const c = el("div", "card");
    const t = el("input");
    t.placeholder = "عنوان السؤال";
    const b = el("textarea");
    b.rows = 3;
    b.placeholder = "تفاصيل إضافية (اختياري)";
    c.appendChild(field("السؤال", t));
    c.appendChild(field("تفاصيل", b));
    const fi = el("input");
    fi.type = "file";
    let qFile = null;
    fi.addEventListener("change", () => { qFile = fi.files[0] || null; });
    c.appendChild(field("إرفاق ملف (اختياري، حتى 10 ميجا)", fi));
    const row = el("div", "row");
    const ok = el("button", "", "إرسال");
    const cancel = el("button", "", "إلغاء");
    cancel.addEventListener("click", () => { state.qform = null; render(); });
    ok.addEventListener("click", async () => {
      if (!t.value.trim()) { say("اكتب السؤال"); return; }
      if (qFile && qFile.size > MAX_ATTACH) { say("الملف أكبر من 10 ميجا"); return; }
      ok.disabled = true;
      let att = {};
      if (qFile) {
        const up = await uploadQAAttachment(qFile);
        if (up.error) { ok.disabled = false; say("تعذّر رفع الملف"); return; }
        att = {
          p_attachment_url: up.data.attachment_url, p_attachment_path: up.data.attachment_path,
          p_attachment_name: up.data.attachment_name, p_attachment_mime: up.data.attachment_mime,
          p_attachment_size: up.data.attachment_size,
        };
      }
      const { error } = await sb.rpc("ask_question", { p_title: t.value.trim(), p_body: b.value.trim() || null, ...att });
      ok.disabled = false;
      if (error) { say("تعذّر إرسال السؤال"); return; }
      state.qform = null;
      say("تم إرسال السؤال");
      await loadData();
    });
    row.appendChild(ok);
    row.appendChild(cancel);
    c.appendChild(row);
    list.appendChild(c);
  }
  if (!state.questions.length) {
    list.appendChild(el("p", "center", "لا يوجد أسئلة حتى الآن"));
    return;
  }
  state.questions.forEach((q) => {
    const c = el("div", "card");
    c.appendChild(el("h3", "", q.title));
    if (q.body) c.appendChild(el("p", "", q.body));
    if (isAdmin()) c.appendChild(el("div", "meta", displayName(q.asker_id)));
    const qAtt = renderQAAttachment(q);
    if (qAtt) c.appendChild(qAtt);
    const approved = approvedAnswers(q.id);
    const pending = pendingAnswers(q.id);
    approved.forEach((a) => {
      const ac = el("div", "row");
      ac.appendChild(el("span", "", "💬 " + a.body + (isAdmin() ? " — " + displayName(a.author_id) : "")));
      if (isAdmin()) {
        const del = el("button", "small danger", "حذف");
        del.addEventListener("click", async () => {
          if (!confirm("حذف الإجابة؟")) return;
          const { data, error } = await sb.rpc("delete_answer", { p_id: a.id });
          if (error) { say("تعذّر الحذف"); return; }
          if (data) {
            await sb.storage.from("attachments").remove([data]);
          }
          await loadData();
        });
        ac.appendChild(del);
      }
      c.appendChild(ac);
      const aAtt = renderQAAttachment(a);
      if (aAtt) c.appendChild(aAtt);
    });
    if (isAdmin()) {
      pending.forEach((a) => {
        const pc = el("div", "row");
        pc.appendChild(el("span", "", "⏳ " + a.body + " — " + displayName(a.author_id)));
        const okb = el("button", "small", "قبول");
        okb.addEventListener("click", async () => {
          const { error } = await sb.rpc("review_answer", { p_answer: a.id, p_approve: true });
          if (error) { say("تعذّر القبول"); return; }
          await loadData();
        });
        const nob = el("button", "small danger", "رفض");
        nob.addEventListener("click", async () => {
          const { error } = await sb.rpc("review_answer", { p_answer: a.id, p_approve: false });
          if (error) { say("تعذّر الرفض"); return; }
          await loadData();
        });
        pc.appendChild(okb);
        pc.appendChild(nob);
        c.appendChild(pc);
        const pAtt = renderQAAttachment(a);
        if (pAtt) c.appendChild(pAtt);
      });
    } else if (myPendingAnswer(q.id)) {
      c.appendChild(el("div", "meta", "إجابتك قيد المراجعة"));
    }
    const canAnswer = isAdmin() || (!approved.length && !myPendingAnswer(q.id));
    if (canAnswer) {
      if (state.answerForm[q.id]) {
        const ab = el("textarea");
        ab.rows = 2;
        ab.placeholder = "اكتب إجابتك";
        c.appendChild(ab);
        const afi = el("input");
        afi.type = "file";
        let aFile = null;
        afi.addEventListener("change", () => { aFile = afi.files[0] || null; });
        c.appendChild(field("إرفاق ملف (اختياري، حتى 10 ميجا)", afi));
        const arow = el("div", "row");
        const asend = el("button", "small", "إرسال الإجابة");
        const acancel = el("button", "small", "إلغاء");
        acancel.addEventListener("click", () => { delete state.answerForm[q.id]; render(); });
        asend.addEventListener("click", async () => {
          if (!ab.value.trim()) { say("اكتب الإجابة"); return; }
          if (aFile && aFile.size > MAX_ATTACH) { say("الملف أكبر من 10 ميجا"); return; }
          asend.disabled = true;
          let att = {};
          if (aFile) {
            const up = await uploadQAAttachment(aFile);
            if (up.error) { asend.disabled = false; say("تعذّر رفع الملف"); return; }
            att = {
              p_attachment_url: up.data.attachment_url, p_attachment_path: up.data.attachment_path,
              p_attachment_name: up.data.attachment_name, p_attachment_mime: up.data.attachment_mime,
              p_attachment_size: up.data.attachment_size,
            };
          }
          const { error } = await sb.rpc("answer_question", { p_question: q.id, p_body: ab.value.trim(), ...att });
          asend.disabled = false;
          if (error) { say("تعذّر إرسال الإجابة"); return; }
          delete state.answerForm[q.id];
          say("تم إرسال الإجابة");
          await loadData();
        });
        arow.appendChild(asend);
        arow.appendChild(acancel);
        c.appendChild(arow);
      } else {
        const ansBtn = el("button", "small", "أجب على السؤال");
        ansBtn.addEventListener("click", () => { state.answerForm[q.id] = true; render(); });
        c.appendChild(ansBtn);
      }
    }
    const canDeleteQ = isAdmin() || (q.asker_id === state.userId && !approved.length);
    if (canDeleteQ) {
      const delq = el("button", "small danger", "حذف السؤال");
      delq.addEventListener("click", async () => {
        if (!confirm("حذف السؤال؟")) return;
        const { data, error } = await sb.rpc("delete_question", { p_id: q.id });
        if (error) { say(/[?&]debug/.test(location.search) ? "تعذّر الحذف: " + error.message : "تعذّر الحذف"); return; }
        if (Array.isArray(data) && data.length) {
          await sb.storage.from("attachments").remove(data);
        }
        await loadData();
      });
      c.appendChild(delq);
    }
    list.appendChild(c);
  });
}


async 
async 

async 
async 
async 




function renderMaterialsAdmin(){
  if (!isAdmin()) return;
  const box=$("dashboard"); if(!box) return; box.replaceChildren();
  const all=[...state.courses].sort((a,b)=>(Number(a.sort_order)||0)-(Number(b.sort_order)||0)||a.name.localeCompare(b.name,"ar"));
  const active=all.filter(c=>c.is_active).length, withDrive=all.filter(c=>!!c.drive_url).length;
  const wrap=el("div","admin-materials-wrap");
  const head=el("div","admin-materials-head"), ht=el("div");
  ht.appendChild(el("h2","dash-title","إدارة المواد")); ht.appendChild(el("p","dash-sub","إضافة وتعديل المواد وروابطها من داخل المنصة.")); head.appendChild(ht);
  const back=el("button","small","رجوع"); back.addEventListener("click",()=>openDevNav("home")); head.appendChild(back); wrap.appendChild(head);
  const stats=el("div","admin-materials-stats"); [[all.length,"إجمالي المواد"],[active,"مواد مفعّلة"],[withDrive,"مواد لها تبييض محاضرات"]].forEach(([n,l])=>{const c=el("div","admin-material-stat");c.appendChild(el("strong","",String(n)));c.appendChild(el("span","",l));stats.appendChild(c);}); wrap.appendChild(stats);
  const add=el("div","admin-material-add"); add.appendChild(el("h3","","إضافة مادة جديدة")); const inp=el("input"); inp.placeholder="اسم المادة"; add.appendChild(inp);
  const addBtn=el("button","","＋ إضافة مادة"); addBtn.addEventListener("click",async()=>{const name=inp.value.trim();if(!name){say("اسم المادة مطلوب");return;}addBtn.disabled=true;const next=all.reduce((m,c)=>Math.max(m,Number(c.sort_order)||0),0)+1;const {error}=await sb.from("courses").insert({name,sort_order:next});addBtn.disabled=false;if(error){say(error.code==="23505"?"المادة موجودة بالفعل":"تعذّر الحفظ");return;}await loadCourses();renderMaterialsAdmin();say("تمت إضافة المادة");}); add.appendChild(addBtn); wrap.appendChild(add);
  const list=el("div","admin-material-list"); if(!all.length) list.appendChild(el("div","dash-empty","لا توجد مواد حاليًا."));
  all.forEach(c=>{
    const card=el("article","admin-material-card"), top=el("div","admin-material-top"), title=el("div","admin-material-title"); title.appendChild(el("div","admin-material-icon","∑")); const th=el("div"); th.appendChild(el("h3","admin-material-title-text",c.name)); th.appendChild(el("div","meta","ID: "+c.id)); title.appendChild(th); top.appendChild(title); top.appendChild(el("span","admin-material-badge"+(c.is_active?"":" off"),c.is_active?"مفعّلة":"متوقفة")); card.appendChild(top);
    const meta=el("div","admin-material-meta"); meta.appendChild(el("div","","📁 تبييض المحاضرات: "+(c.drive_url?"مضاف":"غير مضاف"))); const lc=["whatsapp_link","telegram_link","youtube_link","teams_link"].filter(k=>!!c[k]).length; meta.appendChild(el("div","","🔗 الروابط: "+lc+" / 4")); card.appendChild(meta);
    const actions=el("div","admin-material-actions");
    const rename=el("button","small","تعديل الاسم"); rename.addEventListener("click",async()=>{const raw=prompt("اسم المادة",c.name);if(raw===null)return;const name=raw.trim();if(!name||name===c.name)return;const {error}=await sb.from("courses").update({name}).eq("id",c.id);if(error){say(error.code==="23505"?"الاسم مستخدم بالفعل":"تعذّر الحفظ");return;}await loadCourses();renderMaterialsAdmin();}); actions.appendChild(rename);
    const drive=el("button","small",c.drive_url?"تعديل Drive":"إضافة Drive"); drive.addEventListener("click",async()=>{const raw=prompt("رابط Google Drive للمادة",c.drive_url||"");if(raw===null)return;const url=raw.trim()||null;if(url===(c.drive_url||null))return;const {error}=await sb.from("courses").update({drive_url:url}).eq("id",c.id);if(error){say("تعذّر الحفظ");return;}await loadCourses();renderMaterialsAdmin();}); actions.appendChild(drive);
    [["whatsapp_link","واتساب"],["telegram_link","تيليجرام"],["youtube_link","YouTube"],["teams_link","Teams"]].forEach(([k,l])=>{const b=el("button","small",c[k]?"تعديل "+l:"إضافة "+l);b.addEventListener("click",async()=>{const raw=prompt("رابط "+l+" للمادة",c[k]||"");if(raw===null)return;const url=raw.trim()||null;if(url===(c[k]||null))return;const {error}=await sb.from("courses").update({[k]:url}).eq("id",c.id);if(error){say("تعذّر الحفظ");return;}await loadCourses();renderMaterialsAdmin();});actions.appendChild(b);});
    const tog=el("button","small",c.is_active?"إيقاف المادة":"تفعيل المادة"); tog.addEventListener("click",async()=>{const {error}=await sb.from("courses").update({is_active:!c.is_active}).eq("id",c.id);if(error){say("تعذّر الحفظ");return;}await loadCourses();renderMaterialsAdmin();}); actions.appendChild(tog);
    const at=el("button","small","📎 المرفقات"); at.addEventListener("click",()=>openCourseAttachmentsAdmin(c.id)); actions.appendChild(at);
    if(isFull()){const del=el("button","small danger","حذف");del.addEventListener("click",async()=>{if(!confirm("حذف المادة نهائيًا؟"))return;const {data,error}=await sb.from("courses").delete().eq("id",c.id).select("id");if(error){say(error.code==="23503"?"المادة مرتبطة بعناصر؛ أوقفها أو احذف العناصر المرتبطة أولًا.":"تعذّر الحذف");return;}if(!data?.length){say("تعذّر الحذف");return;}await loadCourses();renderMaterialsAdmin();});actions.appendChild(del);}
    card.appendChild(actions); list.appendChild(card);
  }); wrap.appendChild(list); box.appendChild(wrap);
}

function renderMaterials(){
  const box=$("dashboard");
  if(!box) return;
  box.replaceChildren();
  const active=state.courses.filter(c=>c.is_active).sort((a,b)=>a.sort_order-b.sort_order||a.name.localeCompare(b.name,"ar"));
  if(!active.length){
    box.appendChild(el("div","material-empty","لا توجد مواد متاحة حاليًا."));
    return;
  }
  const head=el("div","dash-head");
  const t=el("div");
  t.appendChild(el("h2","dash-title","المواد"));
  t.appendChild(el("p","dash-sub","المواد المتاحة لك في مكان واحد."));
  head.appendChild(t);
  const choose=el("button","small","تعديل موادّي");
  choose.addEventListener("click",()=>setView("picker"));
  head.appendChild(choose);
  box.appendChild(head);
  const grid=el("div","materials-grid");
  active.forEach(c=>{
    const card=el("article","material-card");
    const top=el("div","material-top");
    top.appendChild(el("div","material-icon","∑"));
    top.appendChild(el("span","material-status",state.mine.has(c.id)?"ضمن موادّي":"متاحة"));
    card.appendChild(top);
    card.appendChild(el("h3","",c.name));
    card.appendChild(el("p","meta",state.mine.has(c.id)?"مضافة إلى موادّي":"يمكنك إضافتها من اختيار المواد."));
    const actions=el("div","material-actions");
    const open=el("button","small","فتح المادة");
    open.addEventListener("click",()=>openCourseDetail(c.id));
    actions.appendChild(open);
    if(c.drive_url){
      const a=el("a","small","📁 تبييض المحاضرات"); a.href=c.drive_url; a.target="_blank"; a.rel="noopener noreferrer"; actions.appendChild(a);
    }
    card.appendChild(actions);
    grid.appendChild(card);
  });
  box.appendChild(grid);
}
function openCourseDetail(id){
  state.active="__course__"+id;
  state.form=null; state.pform=null; state.postForm=null; state.postFocus=null; state.trash=false; state.filter="all"; state.qform=null; state.answerForm={};
  setNavActive("materials");
  render();
}
function renderCourseDetail(id){
  const box=$("dashboard");
  if(!box) return;
  box.replaceChildren();
  const c=state.courses.find(x=>String(x.id)===String(id));
  if(!c){state.active=null;render();return;}
  const wrap=el("div","material-detail");
  const back=el("button","small","← المواد"); back.addEventListener("click",()=>openDevNav("materials"));
  wrap.appendChild(back);
  const head=el("div","material-detail-head");
  const h=el("div"); h.appendChild(el("h2","dash-title",c.name));
  h.appendChild(el("p","dash-sub",state.mine.has(c.id)?"ضمن موادّي":"مادة متاحة"));
  head.appendChild(h); wrap.appendChild(head);
  const info=el("section","dash-card");
  info.appendChild(el("h3","","روابط المادة"));
  const links=el("div","material-detail-links");
  const defs=[["whatsapp_link","واتساب"],["telegram_link","تيليجرام"],["youtube_link","YouTube"],["teams_link","Teams"]];
  defs.forEach(([key,label])=>{if(c[key]){const a=el("a","small",label);a.href=c[key];a.target="_blank";a.rel="noopener noreferrer";links.appendChild(a);}});
  if(c.drive_url){const a=el("a","small","📁 تبييض المحاضرات");a.href=c.drive_url;a.target="_blank";a.rel="noopener noreferrer";links.appendChild(a);}
  if(!links.childElementCount) links.appendChild(el("p","meta","لا توجد روابط مضافة حاليًا."));
  info.appendChild(links); wrap.appendChild(info);
  const att=el("section","dash-card");
  att.appendChild(el("h3","","مرفقات المادة"));
  const attItems = getCourseAttachmentItems(c.id);
  if (!attItems.length) att.appendChild(el("p","meta","لا توجد مرفقات مضافة لهذه المادة حاليًا."));
  else {
    const list=el("div","course-att-list");
    attItems.forEach(it=>{
      const card=el("div","course-att-card");
      const main=el("div"); main.appendChild(el("div","course-att-name",it.title||it.attachment_name||"مرفق"));
      main.appendChild(el("div","course-att-meta",it.attachment_kind==="file" ? (it.attachment_name||"ملف")+(it.attachment_size?" • "+humanSize(it.attachment_size):"") : "رابط خارجي"));
      card.appendChild(main);
      const actions=el("div","course-att-actions");
      const a=el("a","small","فتح"); a.href=it.attachment_url||it.url||"#"; a.target="_blank"; a.rel="noopener noreferrer"; actions.appendChild(a);
      card.appendChild(actions); list.appendChild(card);
    });
    att.appendChild(list);
  }
  if(isAdmin()){ const manage=el("button","small","🛠 إدارة مرفقات المادة"); manage.addEventListener("click",()=>openCourseAttachmentsAdmin(c.id)); att.appendChild(manage); }
  wrap.appendChild(att);
  box.appendChild(wrap);
}


function renderScheduleCalendar(items, box){
  const base = new Date(state.scheduleMonth || new Date());
  base.setDate(1);
  state.scheduleMonth = new Date(base);
  const y=base.getFullYear(), m=base.getMonth();
  const wrap=el("section","schedule-calendar");
  const head=el("div","schedule-calendar-head");
  const title=el("div","schedule-calendar-title",base.toLocaleDateString("ar-EG",{month:"long",year:"numeric"}));
  head.appendChild(title);
  const acts=el("div","schedule-calendar-actions");
  const prev=el("button","small","‹"); const next=el("button","small","›");
  prev.title="الشهر السابق"; next.title="الشهر التالي";
  prev.addEventListener("click",()=>{state.scheduleMonth=new Date(y,m-1,1);render();});
  next.addEventListener("click",()=>{state.scheduleMonth=new Date(y,m+1,1);render();});
  acts.appendChild(prev); acts.appendChild(next); head.appendChild(acts); wrap.appendChild(head);
  const grid=el("div","schedule-calendar-grid");
  ["أحد","اثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت"].forEach(d=>grid.appendChild(el("div","schedule-cal-name",d)));
  const first=new Date(y,m,1); const start=first.getDay();
  const daysInMonth=new Date(y,m+1,0).getDate();
  const prevDays=new Date(y,m,0).getDate();
  const today=new Date();
  const byDay=new Map();
  items.forEach(it=>{
    if(!it.deadline) return;
    const d=new Date(it.deadline); if(Number.isNaN(d.getTime())) return;
    const key=`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    byDay.set(key,(byDay.get(key)||0)+1);
  });
  const total=Math.ceil((start+daysInMonth)/7)*7;
  for(let i=0;i<total;i++){
    let day=i-start+1, yy=y, mm=m, muted=false;
    if(day<1){day=prevDays+day;mm=m-1;muted=true;if(mm<0){mm=11;yy=y-1;}}
    else if(day>daysInMonth){day=day-daysInMonth;mm=m+1;muted=true;if(mm>11){mm=0;yy=y+1;}}
    const cell=el("div","schedule-cal-day"+(muted?" muted":""));
    if(!muted && yy===today.getFullYear() && mm===today.getMonth() && day===today.getDate()) cell.classList.add("today");
    cell.appendChild(el("div","schedule-cal-num",String(day)));
    const count=byDay.get(`${yy}-${mm}-${day}`)||0;
    if(count){
      const dots=el("div","schedule-cal-dots");
      for(let j=0;j<Math.min(count,4);j++) dots.appendChild(el("span","schedule-cal-dot"));
      cell.appendChild(dots);
      cell.appendChild(el("div","schedule-cal-count",count+" موعد"));
    }
    grid.appendChild(cell);
  }
  wrap.appendChild(grid); box.appendChild(wrap);
}


function renderScheduleAdmin(){
  if (!isAdmin()) return;
  const box=$("dashboard");
  if(!box) return;
  box.replaceChildren();
  const sec=findSectionByKind("schedule");
  if(!sec){
    const empty=el("div","schedule-admin-wrap");
    empty.appendChild(el("div","schedule-admin-empty","الجدول غير متاح حاليًا."));
    box.appendChild(empty);
    return;
  }

  const all=state.items.filter(x=>x.section_id===sec.id);
  const live=all.filter(x=>!x.deleted_at);
  const dead=all.filter(x=>x.deleted_at);
  const now=Date.now();
  const upcoming=live.filter(x=>x.deadline && new Date(x.deadline).getTime()>=now)
    .sort((a,b)=>new Date(a.deadline)-new Date(b.deadline));
  const sorted=live.slice().sort((a,b)=>{
    const da=a.deadline?new Date(a.deadline).getTime():Infinity;
    const db=b.deadline?new Date(b.deadline).getTime():Infinity;
    return da-db || new Date(b.created_at)-new Date(a.created_at);
  });

  const wrap=el("div","schedule-admin-wrap");
  const hero=el("div","schedule-admin-hero");
  const h=el("div");
  h.appendChild(el("h2","schedule-admin-title","إدارة الجدول"));
  h.appendChild(el("p","schedule-admin-sub","رتّب المواعيد والأحداث، وحدد وقتًا أو تاريخًا فقط أو اترك الموعد لوقت لاحق."));
  hero.appendChild(h);
  const actions=el("div","schedule-admin-actions");
  const add=el("button","","＋ إضافة موعد");
  add.addEventListener("click",()=>{
    state.form={id:null}; state.pform=null; state.postForm=null; state.trash=false; say(""); render();
  });
  const back=el("button","small","← الرئيسية");
  back.addEventListener("click",()=>openDevNav("home"));
  actions.appendChild(add); actions.appendChild(back);
  hero.appendChild(actions);
  wrap.appendChild(hero);

  const stats=el("div","schedule-admin-stats");
  [["live",""+live.length,"موعد منشور"],["up",""+upcoming.length,"موعد قادم"],["trash",""+dead.length,"في السلة"]].forEach(([k,n,l])=>{
    const s=el("div","schedule-admin-stat");
    s.appendChild(el("strong","",n)); s.appendChild(el("span","",l)); stats.appendChild(s);
  });
  wrap.appendChild(stats);
  renderScheduleCalendar(live, wrap);

  if(state.form){
    const formPanel=el("section","schedule-admin-panel");
    const ph=el("div","schedule-admin-panel-head");
    ph.appendChild(el("h3","",state.form.id?"تعديل الموعد":"إضافة موعد جديد"));
    const cancel=el("button","small","إلغاء");
    cancel.addEventListener("click",()=>{state.form=null;say("");render();});
    ph.appendChild(cancel);
    formPanel.appendChild(ph);
    const it=state.form.id ? all.find(x=>x.id===state.form.id) : null;
    formPanel.appendChild(buildForm(sec,it));
    wrap.appendChild(formPanel);
  }

  const panel=el("section","schedule-admin-panel");
  const ph=el("div","schedule-admin-panel-head");
  ph.appendChild(el("h3","","المواعيد المنشورة"));
  const trashBtn=el("button","small",state.trash?"رجوع":"سلة المحذوفات ("+dead.length+")");
  trashBtn.addEventListener("click",()=>{state.trash=!state.trash;state.form=null;render();});
  ph.appendChild(trashBtn);
  panel.appendChild(ph);

  if(state.trash){
    const trash=dead.slice().sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
    if(!trash.length) panel.appendChild(el("div","schedule-admin-empty","سلة المحذوفات فارغة."));
    else{
      const list=el("div","schedule-admin-list schedule-admin-trash");
      trash.forEach(it=>{
        const row=el("article","schedule-admin-item");
        const d=it.deadline?new Date(it.deadline):null;
        row.appendChild(el("div","schedule-admin-item-date",d&&!Number.isNaN(d.getTime())?d.toLocaleDateString("ar-EG",{day:"numeric",month:"short",year:"numeric"}):"يُحدد لاحقًا"));
        const main=el("div");
        main.appendChild(el("div","schedule-admin-item-title",it.title));
        main.appendChild(el("div","schedule-admin-item-meta",it.course_id!=null?courseName(it.course_id):"موعد عام"));
        row.appendChild(main);
        const acts=el("div","schedule-admin-item-actions");
        const restore=el("button","small","استرجاع");
        restore.addEventListener("click",()=>setDeleted(it.id,false));
        acts.appendChild(restore);
        if(isFull()){
          const purgeBtn=el("button","small danger","حذف نهائي");
          purgeBtn.addEventListener("click",()=>purge(it.id));
          acts.appendChild(purgeBtn);
        }
        row.appendChild(acts); list.appendChild(row);
      });
      panel.appendChild(list);
    }
  }else{
    if(!sorted.length) panel.appendChild(el("div","schedule-admin-empty","لسه مفيش مواعيد. ابدأ بإضافة أول موعد."));
    else{
      const list=el("div","schedule-admin-list");
      sorted.forEach(it=>{
        const row=el("article","schedule-admin-item");
        const d=it.deadline?new Date(it.deadline):null;
        let dateText="يُحدد لاحقًا";
        if(d&&!Number.isNaN(d.getTime())){
          dateText=d.toLocaleDateString("ar-EG",{weekday:"short",day:"numeric",month:"short"});
          if(it.deadline_has_time!==false) dateText+=" · "+d.toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"});
        }
        row.appendChild(el("div","schedule-admin-item-date",dateText));
        const main=el("div");
        main.appendChild(el("div","schedule-admin-item-title",it.title));
        main.appendChild(el("div","schedule-admin-item-meta",(it.course_id!=null?courseName(it.course_id):"موعد عام")+(it.body?" · "+String(it.body).slice(0,90):"")));
        row.appendChild(main);
        const acts=el("div","schedule-admin-item-actions");
        const edit=el("button","small","تعديل");
        edit.addEventListener("click",()=>{state.form={id:it.id};state.trash=false;say("");render();});
        const del=el("button","small danger","حذف");
        del.addEventListener("click",()=>setDeleted(it.id,true));
        acts.appendChild(edit);acts.appendChild(del);
        row.appendChild(acts);list.appendChild(row);
      });
      panel.appendChild(list);
    }
  }
  wrap.appendChild(panel);
  box.appendChild(wrap);
}

function renderSchedule(){
  const box=$("dashboard");
  if(!box) return;
  box.replaceChildren();
  const sec=findSectionByKind("schedule");
  const wrap=el("div","schedule-wrap");
  const head=el("div","schedule-head");
  const h=el("div");
  h.appendChild(el("h2","dash-title","الجدول"));
  h.appendChild(el("p","dash-sub","المواعيد والتكليفات والأحداث المهمة في مكان واحد."));
  head.appendChild(h);
  const back=el("button","small","← الرئيسية");
  back.addEventListener("click",()=>openDevNav("home"));
  head.appendChild(back);
  wrap.appendChild(head);
  if(!sec){ wrap.appendChild(el("div","material-empty","الجدول لسه ما اتنشرش من الإدارة.")); box.appendChild(wrap); return; }
  const items=state.items.filter(x=>x.section_id===sec.id&&!x.deleted_at&&visible(sec,x)).slice().sort((a,b)=>{
    const da=a.deadline?new Date(a.deadline).getTime():Infinity; const db=b.deadline?new Date(b.deadline).getTime():Infinity;
    return da-db||new Date(b.created_at)-new Date(a.created_at);
  });
  if(!items.length){ wrap.appendChild(el("div","material-empty","لا توجد مواعيد منشورة حاليًا.")); box.appendChild(wrap); return; }
  const groups=new Map();
  items.forEach(it=>{
    const d=it.deadline?new Date(it.deadline):null;
    const key=d&&!Number.isNaN(d.getTime())?d.toLocaleDateString("ar-EG",{weekday:"long",day:"numeric",month:"long"}):"مواعيد بدون موعد محدد";
    if(!groups.has(key)) groups.set(key,[]); groups.get(key).push(it);
  });
  const list=el("div","schedule-list");
  groups.forEach((arr,key)=>{
    const day=el("section","schedule-day");
    const dh=el("div","schedule-day-title"); dh.appendChild(el("h3","",key)); dh.appendChild(el("span","meta",String(arr.length)+" موعد")); day.appendChild(dh);
    arr.forEach(it=>{
      const row=el("article","schedule-item");
      const d=it.deadline?new Date(it.deadline):null;
      const tm=d&&!Number.isNaN(d.getTime())?(it.deadline_has_time?d.toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"}):"موعد اليوم"):"لاحقًا";
      row.appendChild(el("div","schedule-time",tm));
      const main=el("div","schedule-main"); main.appendChild(el("div","schedule-title",it.title));
      const meta=it.course_id!=null?courseName(it.course_id):"موعد عام";
      main.appendChild(el("div","schedule-meta",meta));
      if(it.body) main.appendChild(el("div","schedule-meta",String(it.body).slice(0,140)));
      row.appendChild(main);
      row.appendChild(el("span","schedule-kind",it.deadline?"موعد":"حدث"));
      day.appendChild(row);
    });
    list.appendChild(day);
  });
  wrap.appendChild(list); box.appendChild(wrap);
}

function renderSettings(){
  const box=$("settings-box");
  if(!box) return;
  box.replaceChildren();
  const wrap=el("div","settings-wrap");
  const head=el("div","settings-head");
  const ht=el("div");
  ht.appendChild(el("h2","dash-title","الإعدادات والمظهر"));
  ht.appendChild(el("p","dash-sub","عدّل شكل Math 3 من مكان واحد، والتغييرات محفوظة على جهازك."));
  head.appendChild(ht);
  const back=el("button","small","← الرئيسية"); back.addEventListener("click",()=>openDevNav("home")); head.appendChild(back);
  wrap.appendChild(head);
  const grid=el("div","settings-grid");
  const notifications=el("section","settings-card notification-settings-card");
  notifications.appendChild(el("h3","","🔔 إشعارات Math 3"));
  notifications.appendChild(el("p","","إشعارات مباشرة على الجهاز، من غير الحاجة لربط Telegram. تعمل للحساب العادي ولحساب الزائر."));
  const nstatus=el("p","meta","جاري التحقق..."); notifications.appendChild(nstatus);
  const nActions=el("div","settings-actions");
  const toggle=el("button","small","تفعيل الإشعارات"); nActions.appendChild(toggle);
  const disable=el("button","small danger","إيقاف الإشعارات"); nActions.appendChild(disable);
  notifications.appendChild(nActions);
  const types=el("div","notification-types");
  const typeDefs=[["reminders","⏰ التذكيرات"],["new_files","📎 الملفات الجديدة"],["new_posts","📰 المنشورات الجديدة"],["qa","❓ الأسئلة والإجابات"]];
  const typeButtons={};
  typeDefs.forEach(([key,label])=>{ const b=el("button","small",label); b.type="button"; typeButtons[key]=b; b.addEventListener("click",async()=>{ try { const cur=await getNotificationState(); const next=!(cur.preferences?.[key] !== false); await setNotificationType(key,next); renderSettings(); } catch(e){ say("تعذّر حفظ تفضيلات الإشعارات",true); } }); types.appendChild(b); });
  notifications.appendChild(types);
  toggle.addEventListener("click",async()=>{ try { await enableNotifications(); say("تم تفعيل إشعارات Math 3 ✅"); renderSettings(); } catch(e){ const m=e.message==="PERMISSION_DENIED"?"تم رفض إذن الإشعارات من المتصفح.":e.message==="VAPID_NOT_CONFIGURED"?"نظام الإشعارات جاهز، لكن إعداد Web Push لم يكتمل بعد.":"تعذّر تفعيل الإشعارات على هذا الجهاز."; say(m,true); renderSettings(); } });
  disable.addEventListener("click",async()=>{ try { await disableNotifications(); say("تم إيقاف إشعارات Math 3"); renderSettings(); } catch(e){ say("تعذّر إيقاف الإشعارات",true); } });
  getNotificationState().then((ns)=>{ nstatus.textContent=notificationStatusText(ns); toggle.hidden=!!ns.enabled; disable.hidden=!ns.enabled; typeDefs.forEach(([key])=>{ const b=typeButtons[key]; if (b) b.classList.toggle("active", !!ns.preferences?.[key]); }); }).catch(()=>{nstatus.textContent="تعذّر قراءة حالة الإشعارات.";});
  grid.appendChild(notifications);

  const appearance=el("section","settings-card");
  appearance.appendChild(el("h3","","نمط الواجهة"));
  appearance.appendChild(el("p","","فاتح أو داكن أو تلقائي حسب جهازك."));
  const modes=[['auto','تلقائي'],['light','فاتح'],['dark','داكن']];
  const modeRow=el("div","theme-options");
  modes.forEach(([v,label])=>{const b=el("button","theme-option small"+(themeSettings.mode===v?" active":""),label);b.addEventListener("click",()=>{themeSettings.mode=v;saveThemeSettings();applyThemeSettings();renderSettings();});modeRow.appendChild(b);});
  appearance.appendChild(modeRow);
  grid.appendChild(appearance);

  const colors=el("section","settings-card");
  colors.appendChild(el("h3","","اللون الأساسي"));
  colors.appendChild(el("p","","لون الواجهة الرئيسي للكروت والأزرار والعناصر النشطة."));
  const sw=el("div","swatches");
  ['#2b6f9f','#2563eb','#0f766e','#7c3aed','#b45309','#be123c','#334155','#0f172a'].forEach(color=>{const b=el("button","swatch"+(themeSettings.accent.toLowerCase()===color?" active":""));b.type="button";b.title=color;b.style.background=color;b.addEventListener("click",()=>{themeSettings.accent=color;saveThemeSettings();applyThemeSettings();renderSettings();});sw.appendChild(b);});
  colors.appendChild(sw);
  const custom=el("input"); custom.type="color"; custom.value=/^#[0-9a-f]{6}$/i.test(themeSettings.accent)?themeSettings.accent:'#2b6f9f'; custom.addEventListener("change",()=>{themeSettings.accent=custom.value;saveThemeSettings();applyThemeSettings();renderSettings();});
  colors.appendChild(field("لون مخصص",custom));
  grid.appendChild(colors);

  const layout=el("section","settings-card");
  layout.appendChild(el("h3","","المساحة والشكل"));
  layout.appendChild(el("p","","تحكم بسيط في اتساع المحتوى واستدارة الكروت."));
  const width=el("input"); width.type="range"; width.min="760"; width.max="1400"; width.step="20"; width.value=themeSettings.width;
  const radius=el("input"); radius.type="range"; radius.min="10"; radius.max="28"; radius.step="1"; radius.value=themeSettings.radius;
  const widthLabel=el("label","","عرض المحتوى: "+themeSettings.width+"px");
  const row1=el("div","settings-row");row1.appendChild(widthLabel);row1.appendChild(width);layout.appendChild(row1);
  const radiusLabel=el("label","","استدارة الكروت: "+themeSettings.radius+"px");
  const row2=el("div","settings-row");row2.appendChild(radiusLabel);row2.appendChild(radius);layout.appendChild(row2);
  width.addEventListener("input",()=>{themeSettings.width=Number(width.value);widthLabel.textContent="عرض المحتوى: "+themeSettings.width+"px";saveThemeSettings();applyThemeSettings();});
  radius.addEventListener("input",()=>{themeSettings.radius=Number(radius.value);radiusLabel.textContent="استدارة الكروت: "+themeSettings.radius+"px";saveThemeSettings();applyThemeSettings();});
  grid.appendChild(layout);

  const density=el("section","settings-card");
  density.appendChild(el("h3","","الخط والخلفية"));
  density.appendChild(el("p","","تعديلات خفيفة من غير ما نغيّر هوية Math 3."));
  const fs=el("input");fs.type="range";fs.min="16";fs.max="21";fs.step="1";fs.value=themeSettings.fontSize;
  const wp=el("input");wp.type="range";wp.min="0";wp.max=".22";wp.step=".01";wp.value=themeSettings.wallpaper;
  const pp=el("input");pp.type="range";pp.min="0";pp.max=".28";pp.step=".01";pp.value=themeSettings.pattern;
  const fsLabel=el("label","","حجم الخط: "+themeSettings.fontSize+"px");
  const r3=el("div","settings-row");r3.appendChild(fsLabel);r3.appendChild(fs);density.appendChild(r3);
  const wpLabel=el("label","","وضوح الخلفية: "+Math.round(themeSettings.wallpaper*100)+"%");
  const r4=el("div","settings-row");r4.appendChild(wpLabel);r4.appendChild(wp);density.appendChild(r4);
  const ppLabel=el("label","","نقشة الرياضيات: "+Math.round(themeSettings.pattern*100)+"%");
  const r5=el("div","settings-row");r5.appendChild(ppLabel);r5.appendChild(pp);density.appendChild(r5);
  fs.addEventListener("input",()=>{themeSettings.fontSize=Number(fs.value);fsLabel.textContent="حجم الخط: "+themeSettings.fontSize+"px";saveThemeSettings();applyThemeSettings();});
  wp.addEventListener("input",()=>{themeSettings.wallpaper=Number(wp.value);wpLabel.textContent="وضوح الخلفية: "+Math.round(themeSettings.wallpaper*100)+"%";saveThemeSettings();applyThemeSettings();});
  pp.addEventListener("input",()=>{themeSettings.pattern=Number(pp.value);ppLabel.textContent="نقشة الرياضيات: "+Math.round(themeSettings.pattern*100)+"%";saveThemeSettings();applyThemeSettings();});
  grid.appendChild(density);

  const preview=el("section","settings-card");preview.appendChild(el("h3","","معاينة"));preview.appendChild(el("p","","المعاينة تستخدم نفس ألوان الواجهة الحالية."));
  const pv=el("div","settings-preview");const pc=el("div","settings-preview-card");pc.appendChild(el("h3","","Math 3"));pc.appendChild(el("p","meta","كارت تجريبي للمظهر الحالي"));const br=el("div","settings-actions");br.appendChild(el("button","small","زر أساسي"));br.appendChild(el("button","small","زر ثانوي"));pc.appendChild(br);pv.appendChild(pc);preview.appendChild(pv);
  const acts=el("div","settings-actions");const reset=el("button","small danger","إعادة الافتراضي");reset.addEventListener("click",()=>{if(confirm("إرجاع إعدادات المظهر للوضع الافتراضي؟"))resetThemeSettings();});acts.appendChild(reset);preview.appendChild(acts);grid.appendChild(preview);

  wrap.appendChild(grid);box.appendChild(wrap);
}

function renderDashboard() {
  const box = $("dashboard");
  if (!box) return;
  box.replaceChildren();

  const activeCourses = state.courses.filter((c) => c.is_active);
  const taskSec = findSectionByKind("tasks");
  const taskItems = taskSec ? state.items.filter((x) => x.section_id === taskSec.id && !x.deleted_at && visible(taskSec, x)) : [];
  const upcoming = taskItems
    .filter((x) => x.deadline)
    .sort((a,b) => new Date(a.deadline) - new Date(b.deadline))
    .slice(0,4);
  const allPosts = (state.posts || []).filter((p) => !p.deleted_at).slice().sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
  const posts = allPosts.slice(0,3);
  const newsletterSec = findSectionByKind("newsletter");
  const newsletters = newsletterSec ? state.items.filter((x) => x.section_id === newsletterSec.id && !x.deleted_at).slice().sort((a,b) => new Date(b.created_at)-new Date(a.created_at)).slice(0,2) : [];

  const head = el("div", "dash-head");
  const headText = el("div");
  headText.appendChild(el("h2", "dash-title", "الرئيسية"));
  headText.appendChild(el("p", "dash-sub", "كل ما تحتاجه في مكان واحد، بدون زحمة."));
  head.appendChild(headText);
  const quick = el("div", "dash-actions");
  const mat = el("button", "small", "📚 المواد");
  mat.addEventListener("click", () => openDevNav("materials"));
  quick.appendChild(mat);
  const sch = el("button", "small", "📅 الجدول");
  sch.addEventListener("click", () => openDevNav("schedule"));
  quick.appendChild(sch);
  head.appendChild(quick);
  box.appendChild(head);

  const grid = el("div", "dash-grid");
  const stats = [
    [activeCourses.length, "مادة متاحة"],
    [taskItems.length, "تكليف منشور"],
    [allPosts.length, "منشور متاح"],
  ];
  stats.forEach(([n,label]) => {
    const c=el("div","dash-card"); c.appendChild(el("div","dash-count",String(n))); c.appendChild(el("div","dash-stat-label",label)); grid.appendChild(c);
  });

  const tasksCard=el("section","dash-card dash-wide");
  tasksCard.appendChild(el("h3","","📌 التكاليف القادمة"));
  const taskList=el("div","dash-list");
  if (!upcoming.length) taskList.appendChild(el("p","dash-empty","لا توجد تكاليف بموعد محدد حاليًا."));
  upcoming.forEach((it)=>{
    const row=el("div","dash-item"); const main=el("div","dash-item-main");
    main.appendChild(el("div","dash-item-title",it.title));
    main.appendChild(el("div","dash-meta",courseName(it.course_id) || "تكليف عام"));
    main.appendChild(el("div","dash-meta",fmtDeadline(it))); row.appendChild(main);
    const b=el("button","small","فتح التكاليف"); b.addEventListener("click",()=>openDevNav("tasks")); row.appendChild(b);
    taskList.appendChild(row);
  });
  tasksCard.appendChild(taskList); grid.appendChild(tasksCard);

  const newsCard=el("section","dash-card dash-side");
  newsCard.appendChild(el("h3","","📰 النشرة الأسبوعية"));
  const nl=el("div","dash-list");
  if(!newsletters.length) nl.appendChild(el("p","dash-empty","لا توجد نشرة أسبوعية منشورة حاليًا."));
  newsletters.forEach((it)=>{const row=el("div","dash-item"); const main=el("div","dash-item-main"); main.appendChild(el("div","dash-item-title",it.title)); main.appendChild(el("div","dash-meta",it.created_at?new Date(it.created_at).toLocaleDateString("ar-EG"):"")); row.appendChild(main); if(it.url){const a=el("a","small","فتح PDF");a.href=it.url;a.target="_blank";a.rel="noopener";row.appendChild(a);} nl.appendChild(row);});
  newsCard.appendChild(nl); grid.appendChild(newsCard);

  const postsCard=el("section","dash-card dash-wide");
  postsCard.appendChild(el("h3","","📬 أحدث المنشورات"));
  const pl=el("div","dash-list");
  if(!posts.length) pl.appendChild(el("p","dash-empty","لا توجد منشورات حتى الآن."));
  posts.forEach((p)=>{const row=el("div","dash-item");const main=el("div","dash-item-main");main.appendChild(el("div","dash-item-title",p.content?String(p.content).slice(0,90):"منشور بصورة"));main.appendChild(el("div","dash-meta",p.created_at?new Date(p.created_at).toLocaleDateString("ar-EG"):""));row.appendChild(main);const b=el("button","small","المنشورات");b.addEventListener("click",()=>openDevNav("posts"));row.appendChild(b);pl.appendChild(row);});
  postsCard.appendChild(pl); grid.appendChild(postsCard);

  const matCard=el("section","dash-card dash-side");
  matCard.appendChild(el("h3","","📚 المواد"));
  const ml=el("div","dash-list");
  activeCourses.slice(0,5).forEach((c)=>{const row=el("div","dash-item");const main=el("div","dash-item-main");main.appendChild(el("div","dash-item-title",c.name));main.appendChild(el("div","dash-meta",state.mine.has(c.id)?"مضافة إلى موادّي":"متاحة للاختيار"));row.appendChild(main);ml.appendChild(row);});
  if(!activeCourses.length) ml.appendChild(el("p","dash-empty","لا توجد مواد متاحة حاليًا."));
  matCard.appendChild(ml); grid.appendChild(matCard);

  grid.appendChild((()=>{const c=el("section","dash-card dash-full");c.appendChild(el("h3","","✨ اختصارات"));const r=el("div","dash-actions");[["📚 المواد","materials"],["📝 التكاليف","tasks"],["📅 الجدول","schedule"],["📰 النشرة الأسبوعية","newsletter"],["📬 المنشورات","posts"],["❓ الأسئلة","qa"]].forEach(([label,key])=>{const b=el("button","small",label);b.addEventListener("click",()=>openDevNav(key));r.appendChild(b);});c.appendChild(r);return c;})());
  box.appendChild(grid);
}


function getCourseAttachmentSection(){
  return state.sections.find(s=>s.kind==="course_attachments") || null;
}
function getCourseAttachmentItems(courseId){
  const sec=getCourseAttachmentSection();
  if(!sec) return [];
  return state.items.filter(it=>String(it.section_id)===String(sec.id) && String(it.course_id)===String(courseId) && !it.deleted_at).sort((a,b)=>(a.created_at||"").localeCompare(b.created_at||""));
}
async function openCourseAttachmentsAdmin(courseId){
  if (!isAdmin()) return;
  if(!isAdmin()) return;
  showLoading(true);
  let sec=getCourseAttachmentSection();
  if(!sec){
    const maxOrder=state.sections.reduce((m,x)=>Math.max(m,Number(x.sort_order)||0),0);
    const {data,error}=await sb.from("sections").insert({title:"مرفقات المواد",kind:"course_attachments",sort_order:maxOrder+1,is_active:true}).select("id,title,kind,sort_order").single();
    if(error){showLoading(false);say("تعذّر إنشاء مساحة مرفقات المواد");return;}
    sec=data; state.sections.push(sec);
  }
  showLoading(false);
  state.active="__course_att_admin__"+courseId;
  state.courseAttachmentCourseId=Number(courseId);
  state.form=null; state.pform=null; state.postForm=null; state.postFocus=null; state.trash=false;
  setNavActive("materials"); render();
}
function renderCourseAttachmentsAdmin(courseId){
  if (!isAdmin()) return;
  const box=$("dashboard"); if(!box) return; box.replaceChildren();
  const c=state.courses.find(x=>String(x.id)===String(courseId));
  const sec=getCourseAttachmentSection();
  if(!c||!sec){box.appendChild(el("p","dash-empty","تعذّر فتح مرفقات المادة."));return;}
  const wrap=el("div","course-att-admin");
  const back=el("button","small","← المادة"); back.addEventListener("click",()=>openCourseDetail(c.id)); wrap.appendChild(back);
  const head=el("div","course-att-head"); const t=el("div"); t.appendChild(el("h2","dash-title","مرفقات: "+c.name)); t.appendChild(el("p","dash-sub","ملفات وروابط خاصة بهذه المادة فقط.")); head.appendChild(t);
  const add=el("button","small","＋ إضافة مرفق"); add.addEventListener("click",()=>{state.form=null;state.courseAttForm={courseId:Number(courseId)};render();}); head.appendChild(add); wrap.appendChild(head);
  if(state.courseAttForm && Number(state.courseAttForm.courseId)===Number(courseId)) wrap.appendChild(renderCourseAttachmentForm(c,sec));
  const list=el("div","course-att-list");
  const items=getCourseAttachmentItems(courseId);
  if(!items.length) list.appendChild(el("div","dash-empty","لا توجد مرفقات بعد. أضف أول مرفق للمادة."));
  items.forEach(it=>{
    const card=el("div","course-att-card"); const main=el("div"); main.appendChild(el("div","course-att-name",it.title||it.attachment_name||"مرفق")); main.appendChild(el("div","course-att-meta",it.attachment_kind==="file"?(it.attachment_name||"ملف")+(it.attachment_size?" • "+humanSize(it.attachment_size):""):"رابط خارجي")); card.appendChild(main);
    const actions=el("div","course-att-actions"); const open=el("a","small","فتح"); open.href=it.attachment_url||it.url||"#"; open.target="_blank"; open.rel="noopener noreferrer"; actions.appendChild(open);
    const del=el("button","small danger","حذف"); del.addEventListener("click",async()=>{if(!confirm("حذف هذا المرفق؟"))return;const {error}=await sb.from("items").update({deleted_at:new Date().toISOString()}).eq("id",it.id);if(error){say("تعذّر الحذف");return;}await loadData();render();}); actions.appendChild(del); card.appendChild(actions); list.appendChild(card);
  });
  wrap.appendChild(list); box.appendChild(wrap);
}
function renderCourseAttachmentForm(c,sec){
  if (!isAdmin()) return el("div", "card", "غير مسموح");
  const box=el("div","course-att-form"); let file=null;
  const title=el("input"); title.placeholder="اسم المرفق"; box.appendChild(field("اسم المرفق",title));
  const fi=el("input"); fi.type="file"; box.appendChild(field("رفع ملف",fi)); fi.addEventListener("change",()=>file=fi.files[0]||null);
  const url=el("input"); url.type="url"; url.dir="ltr"; url.placeholder="https://..."; box.appendChild(field("أو رابط خارجي",url));
  const row=el("div","row"); const save=el("button","","حفظ"); const cancel=el("button","","إلغاء");
  cancel.addEventListener("click",()=>{state.courseAttForm=null;render();});
  save.addEventListener("click",async()=>{const name=title.value.trim();const link=url.value.trim();if(!name){say("اسم المرفق مطلوب");return;}if(file&&link){say("اختَر ملفًا أو رابطًا، وليس الاثنين معًا");return;}save.disabled=true;let data={title:name,course_id:Number(c.id),section_id:sec.id,created_at:new Date().toISOString()};if(file){file=await shrinkImage(file);if(file.size>MAX_ATTACH){save.disabled=false;say("الملف أكبر من 10 ميجا");return;}const up=await uploadAttachment(sec.id,file);if(up.error){save.disabled=false;say("تعذّر رفع الملف");return;}Object.assign(data,up.data);}else if(link){const u=safeUrl(link);if(!u){save.disabled=false;say("الرابط غير صالح");return;}Object.assign(data,{attachment_kind:"link",attachment_url:u,attachment_path:null,attachment_name:null,attachment_mime:null,attachment_size:null});}else{save.disabled=false;say("أضف ملفًا أو رابطًا");return;}const {error}=await sb.from("items").insert(data);save.disabled=false;if(error){say("تعذّر حفظ المرفق");return;}state.courseAttForm=null;await loadData();say("تمت إضافة المرفق");render();});
  row.appendChild(save);row.appendChild(cancel);box.appendChild(row);return box;
}


function renderNewsletterAdmin(){
  if (!isAdmin()) return;
  const box=$("dashboard"); if(!box) return; box.replaceChildren();
  const sec=findSectionByKind("newsletter");
  if(!sec){box.appendChild(el("div","schedule-admin-empty","قسم النشرة الأسبوعية غير متاح حاليًا."));return;}
  const all=state.items.filter(x=>String(x.section_id)===String(sec.id));
  const live=all.filter(x=>!x.deleted_at);
  const dead=all.filter(x=>x.deleted_at);
  const wrap=el("div","schedule-admin-wrap");
  const hero=el("div","schedule-admin-hero"); const h=el("div");
  h.appendChild(el("h2","schedule-admin-title","إدارة النشرة الأسبوعية"));
  h.appendChild(el("p","schedule-admin-sub","إضافة وتعديل وحذف أعداد النشرة الأسبوعية من مكان واحد.")); hero.appendChild(h);
  const actions=el("div","schedule-admin-actions");
  const add=el("button","","＋ إضافة عدد"); add.addEventListener("click",()=>{state.form={id:null};state.trash=false;render();});
  const back=el("button","small","← لوحة الإدارة"); back.addEventListener("click",()=>{state.active="__admin_dashboard__";state.form=null;render();});
  actions.appendChild(add);actions.appendChild(back);hero.appendChild(actions);wrap.appendChild(hero);
  const stats=el("div","schedule-admin-stats");
  [[live.length,"عدد منشور"],[dead.length,"في السلة"],[live.filter(x=>!!x.url).length,"بروابط PDF"]].forEach(([n,l])=>{const c=el("div","schedule-admin-stat");c.appendChild(el("strong","",String(n)));c.appendChild(el("span","",l));stats.appendChild(c);});
  wrap.appendChild(stats);
  if(state.form){const panel=el("section","schedule-admin-panel");const ph=el("div","schedule-admin-panel-head");ph.appendChild(el("h3","",state.form.id?"تعديل العدد":"إضافة عدد جديد"));const cancel=el("button","small","إلغاء");cancel.addEventListener("click",()=>{state.form=null;render();});ph.appendChild(cancel);panel.appendChild(ph);panel.appendChild(buildForm(sec,state.form.id?all.find(x=>x.id===state.form.id):null));wrap.appendChild(panel);}
  const panel=el("section","schedule-admin-panel");const ph=el("div","schedule-admin-panel-head");ph.appendChild(el("h3","","الأعداد"));
  const trashBtn=el("button","small",state.trash?"رجوع":"سلة المحذوفات ("+dead.length+")");trashBtn.addEventListener("click",()=>{state.trash=!state.trash;state.form=null;render();});ph.appendChild(trashBtn);panel.appendChild(ph);
  const list=el("div","schedule-admin-list");
  const rows=(state.trash?dead:live).slice().sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  if(!rows.length) panel.appendChild(el("div","schedule-admin-empty",state.trash?"سلة المحذوفات فارغة.":"لسه مفيش أعداد منشورة. ابدأ بإضافة أول عدد."));
  rows.forEach(it=>{
    const row=el("article","schedule-admin-item");
    row.appendChild(el("div","schedule-admin-item-date",it.created_at?new Date(it.created_at).toLocaleDateString("ar-EG",{weekday:"short",day:"numeric",month:"short",year:"numeric"}):""));
    const main=el("div"); main.appendChild(el("div","schedule-admin-item-title",it.title)); main.appendChild(el("div","schedule-admin-item-meta",it.url?"ملف PDF مرتبط":"بدون رابط PDF")); row.appendChild(main);
    const acts=el("div","schedule-admin-item-actions");
    if(it.url){const open=el("a","small","فتح PDF");open.href=it.url;open.target="_blank";open.rel="noopener noreferrer";acts.appendChild(open);}
    if(state.trash){const restore=el("button","small","استرجاع");restore.addEventListener("click",()=>setDeleted(it.id,false));acts.appendChild(restore);if(isFull()){const purgeBtn=el("button","small danger","حذف نهائي");purgeBtn.addEventListener("click",()=>purge(it.id));acts.appendChild(purgeBtn);}}
    else{const edit=el("button","small","تعديل");edit.addEventListener("click",()=>{state.form={id:it.id};render();});const del=el("button","small danger","حذف");del.addEventListener("click",()=>setDeleted(it.id,true));acts.appendChild(edit);acts.appendChild(del);}
    row.appendChild(acts);list.appendChild(row);
  });
  panel.appendChild(list);wrap.appendChild(panel);box.appendChild(wrap);
}

function renderTasksAdmin(){
  if (!isAdmin()) return;
  const box=$("dashboard"); if(!box) return; box.replaceChildren();
  const sec=findSectionByKind("tasks");
  if(!sec){box.appendChild(el("div","schedule-admin-empty","قسم التكاليف غير متاح حاليًا."));return;}
  const all=state.items.filter(x=>String(x.section_id)===String(sec.id));
  const live=all.filter(x=>!x.deleted_at);
  const dead=all.filter(x=>x.deleted_at);
  const now=Date.now();
  const due=live.filter(x=>x.deadline).sort((a,b)=>new Date(a.deadline)-new Date(b.deadline));
  const upcoming=due.filter(x=>new Date(x.deadline).getTime()>=now).length;
  const overdue=due.filter(x=>new Date(x.deadline).getTime()<now).length;
  const wrap=el("div","schedule-admin-wrap");
  const hero=el("div","schedule-admin-hero"); const h=el("div");
  h.appendChild(el("h2","schedule-admin-title","إدارة التكاليف"));
  h.appendChild(el("p","schedule-admin-sub","أضف وعدّل التكليفات ومواعيد التسليم من مكان واحد.")); hero.appendChild(h);
  const actions=el("div","schedule-admin-actions");
  const add=el("button","","＋ إضافة تكليف"); add.addEventListener("click",()=>{state.form={id:null};state.pform=null;state.trash=false;render();});
  const back=el("button","small","← لوحة الإدارة"); back.addEventListener("click",()=>{state.active="__admin_dashboard__";render();});
  actions.appendChild(add);actions.appendChild(back);hero.appendChild(actions);wrap.appendChild(hero);
  const stats=el("div","schedule-admin-stats");
  [[live.length,"تكليف منشور"],[upcoming,"موعد قادم"],[overdue,"موعد منتهٍ"],[dead.length,"في السلة"]].forEach(([n,l])=>{const c=el("div","schedule-admin-stat");c.appendChild(el("strong","",String(n)));c.appendChild(el("span","",l));stats.appendChild(c);});
  wrap.appendChild(stats);
  if(state.form){const panel=el("section","schedule-admin-panel");const ph=el("div","schedule-admin-panel-head");ph.appendChild(el("h3","",state.form.id?"تعديل التكليف":"إضافة تكليف جديد"));const cancel=el("button","small","إلغاء");cancel.addEventListener("click",()=>{state.form=null;render();});ph.appendChild(cancel);panel.appendChild(ph);panel.appendChild(buildForm(sec,state.form.id?all.find(x=>x.id===state.form.id):null));wrap.appendChild(panel);}
  const panel=el("section","schedule-admin-panel");const ph=el("div","schedule-admin-panel-head");ph.appendChild(el("h3","","التكاليف المنشورة"));
  const trashBtn=el("button","small",state.trash?"رجوع":"سلة المحذوفات ("+dead.length+")");trashBtn.addEventListener("click",()=>{state.trash=!state.trash;state.form=null;render();});ph.appendChild(trashBtn);panel.appendChild(ph);
  const list=el("div","schedule-admin-list");
  const rows=(state.trash?dead.slice().sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)):live.slice().sort((a,b)=>{const da=a.deadline?new Date(a.deadline).getTime():Infinity,db=b.deadline?new Date(b.deadline).getTime():Infinity;return da-db||new Date(b.created_at)-new Date(a.created_at);}));
  if(!rows.length){panel.appendChild(el("div","schedule-admin-empty",state.trash?"سلة المحذوفات فارغة.":"لسه مفيش تكاليف. ابدأ بإضافة أول تكليف."));}
  rows.forEach(it=>{
    const row=el("article","schedule-admin-item"); const d=it.deadline?new Date(it.deadline):null; let dateText="بدون موعد تسليم";
    if(d&&!Number.isNaN(d.getTime())){dateText=d.toLocaleDateString("ar-EG",{weekday:"short",day:"numeric",month:"short"}); if(it.deadline_has_time!==false) dateText+=" · "+d.toLocaleTimeString("ar-EG",{hour:"2-digit",minute:"2-digit"});}
    row.appendChild(el("div","schedule-admin-item-date",dateText));
    const main=el("div"); main.appendChild(el("div","schedule-admin-item-title",it.title)); main.appendChild(el("div","schedule-admin-item-meta",(it.course_id!=null?courseName(it.course_id):"تكليف عام")+(it.body?" · "+String(it.body).slice(0,90):""))); row.appendChild(main);
    const acts=el("div","schedule-admin-item-actions");
    if(state.trash){const restore=el("button","small","استرجاع");restore.addEventListener("click",()=>setDeleted(it.id,false));acts.appendChild(restore);if(isFull()){const purgeBtn=el("button","small danger","حذف نهائي");purgeBtn.addEventListener("click",()=>purge(it.id));acts.appendChild(purgeBtn);}}
    else{const edit=el("button","small","تعديل");edit.addEventListener("click",()=>{state.form={id:it.id};render();});const del=el("button","small danger","حذف");del.addEventListener("click",()=>setDeleted(it.id,true));acts.appendChild(edit);acts.appendChild(del);}
    row.appendChild(acts);list.appendChild(row);
  });
  panel.appendChild(list);wrap.appendChild(panel);box.appendChild(wrap);
}

function render() {
  renderBotBanner();
  renderDynamicNav();
  renderAdminNav();
  const dashboard = $("dashboard");
  const tabs = $("tabs");
  if (dashboard) dashboard.hidden = !!state.active;
  tabs.hidden = !state.active;
  $("chips").hidden = !state.active;
  $("list").hidden = !state.active;
  if (!state.active) {
    renderDashboard();
    return;
  }
  if (state.active === "__sections_admin__") {
    renderSectionsAdmin(); tabs.hidden=true; $("chips").hidden=true; $("list").hidden=true; return;
  }
  if (state.active === "__admin_dashboard__") {
    renderAdminDashboard();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (state.active === "__tasks_admin__") {
    renderTasksAdmin();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (state.active === "__newsletter_admin__") {
    renderNewsletterAdmin();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (state.active === "__schedule_admin__") {
    renderScheduleAdmin();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (state.active === "__schedule__") {
    renderSchedule();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (String(state.active).startsWith("__course_att_admin__")) {
    renderCourseAttachmentsAdmin(String(state.active).slice("__course_att_admin__".length));
    tabs.hidden = true; $("chips").hidden = true; $("list").hidden = true; return;
  }
  if (state.active === "__materials__") {
    renderMaterials();
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }
  if (String(state.active).startsWith("__course__")) {
    renderCourseDetail(String(state.active).slice("__course__".length));
    tabs.hidden = true;
    $("chips").hidden = true;
    $("list").hidden = true;
    return;
  }

  tabs.replaceChildren();

  const postsBtn = el("button", "tab" + (state.active === "__posts__" ? " active" : ""), "المنشورات");
  postsBtn.addEventListener("click", () => {
    state.active = "__posts__";
    state.form = null;
    state.pform = null;
    state.postForm = null;
    state.postFocus = null;
    state.trash = false;
    state.filter = "all";
    state.qform = null;
    state.answerForm = {};
    render();
  });
  tabs.appendChild(postsBtn);
  
  state.sections.forEach((sec) => {
    const b = el("button", "tab" + (sec.id === state.active ? " active" : ""), sec.title);
    b.addEventListener("click", () => {
      state.active = sec.id; state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
      state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
      render();
    });
    tabs.appendChild(b);
  });
  const list = $("list");
  list.replaceChildren();

  if (state.active === "__posts__") {
    $("chips").replaceChildren();
    renderPosts();
    return;
  }
  
  const sec = state.sections.find((x) => x.id === state.active);
  if (!sec) { $("chips").replaceChildren(); return; }
  if (sec.kind === "qa") { renderQA(sec); return; }
  if (sec.kind === "links") { renderLinks(sec); return; }
  renderChips(sec);
  const inSec = state.items.filter((x) => x.section_id === sec.id);
  const dead = inSec.filter((x) => x.deleted_at);
  const live = inSec.filter((x) => !x.deleted_at && visible(sec, x));
  const isTasks = sec.kind === "tasks";
  const bar = el("div", "row");
  if (isAdmin()) {
    const add = el("button", "", "+ إضافة");
    add.addEventListener("click", () => { state.form = { id: null }; state.pform = null; state.trash = false; say(""); render(); });
    const tr = el("button", "", state.trash ? "رجوع" : "سلة المحذوفات (" + dead.length + ")");
    tr.addEventListener("click", () => { state.trash = !state.trash; state.form = null; state.pform = null; render(); });
    bar.appendChild(add);
    bar.appendChild(tr);
  }
  if (isFull() && state.trash && dead.length) {
    const et = el("button", "danger", "تفريغ السلة");
    et.addEventListener("click", () => emptyTrash(dead.map((x) => x.id)));
    bar.appendChild(et);
  }
  if (isTasks && !state.trash) {
    const pa = el("button", "", "+ عنصر شخصي");
    pa.addEventListener("click", () => { state.pform = { id: null }; state.form = null; say(""); render(); });
    bar.appendChild(pa);
  }
  if (bar.children.length) list.appendChild(bar);
  if (state.form) {
    const it = state.form.id ? state.items.find((x) => x.id === state.form.id) : null;
    list.appendChild(buildForm(sec, it));
  }
  if (state.pform && isTasks && !state.trash) {
    const p = state.pform.id ? state.personal.find((x) => x.id === state.pform.id) : null;
    list.appendChild(buildPersonalForm(p));
  }
  let entries;
  if (state.trash) {
    entries = dead.map((it) => ({ k: "c", it }));
  } else {
    entries = live.map((it) => ({ k: "c", it }));
    if (isTasks && (state.filter === "all" || state.filter === "personal")) {
      state.personal.forEach((p) => entries.push({ k: "p", p }));
    }
  }
  const dlOf = (e) => {
    const d = e.k === "c" ? e.it.deadline : e.p.deadline;
    return d ? new Date(d).getTime() : Infinity;
  };
  const doneOf = (e) => (e.k === "c" ? isDone(e.it) : e.p.done) ? 1 : 0;
  const createdOf = (e) => new Date(e.k === "c" ? e.it.created_at : e.p.created_at).getTime();
  if (isTasks) {
    entries.sort((a, b) => {
      if (doneOf(a) !== doneOf(b)) return doneOf(a) - doneOf(b);
      if (dlOf(a) !== dlOf(b)) return dlOf(a) < dlOf(b) ? -1 : 1;
      return createdOf(a) - createdOf(b);
    });
  } else {
    entries.sort((a, b) => createdOf(b) - createdOf(a));
  }
  if (!entries.length) {
    list.appendChild(el("p", "center", state.trash ? "السلة فارغة" : "لا يوجد شيء هنا حتى الآن"));
  }
  entries.forEach((e) => list.appendChild(e.k === "c" ? card(sec, e.it) : personalCard(e.p)));
}
/* الدخول والحساب */
function hideAll() {
  $("side-nav").hidden = true;
  $("admin-nav-extra").hidden = true;
  $("app").hidden = true;
  $("picker-box").hidden = true;
  $("courses-box").hidden = true;
  $("people-box").hidden = true;
  $("log-box").hidden = true;
  $("settings-box").hidden = true;
  $("courses-btn").hidden = true;
  $("manage-btn").hidden = true;
  $("people-btn").hidden = true;
  $("log-btn").hidden = true;
  $("backup-btn").hidden = true;
  $("links-fab").hidden = true;
  $("links-panel").hidden = true;
}
function openAdminDashboard() {
  if (!isAdmin()) return;
  state.active = "__admin_dashboard__";
  state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
  state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
  setNavActive(null);
  render();
}
function renderAdminDashboard() {
  const box = $("dashboard");
  if (!box) return;
  box.replaceChildren();
  const wrap = el("div", "admin-dashboard-wrap");
  const head = el("div", "admin-dashboard-head");
  const intro = el("div");
  intro.appendChild(el("h2", "admin-dashboard-title", "لوحة الإدارة"));
  intro.appendChild(el("p", "admin-dashboard-sub", "إدارة محتوى Math 3 من مكان واحد، بدون الدخول للكود."));
  head.appendChild(intro);
  wrap.appendChild(head);

  const activeCourses = (state.courses || []).filter(c => c.is_active);
  const schedule = findSectionByKind("schedule");
  const scheduleItems = schedule ? (state.items || []).filter(x => String(x.section_id) === String(schedule.id) && !x.deleted_at) : [];
  const livePosts = (state.posts || []).filter(p => !p.deleted_at);
  const tasksSec = findSectionByKind("tasks");
  const taskCount = tasksSec ? (state.items || []).filter(x => String(x.section_id) === String(tasksSec.id) && !x.deleted_at).length : 0;
  const stats = el("div", "admin-dashboard-grid");
  [[activeCourses.length,"مادة مفعّلة"],[scheduleItems.length,"موعد منشور"],[livePosts.length,"منشور ظاهر"],[taskCount,"تكليف منشور"]].forEach(([n,l])=>{const c=el("div","admin-dashboard-stat");c.appendChild(el("strong","",String(n)));c.appendChild(el("span","",l));stats.appendChild(c);});
  wrap.appendChild(stats);

  const panels = el("div", "admin-dashboard-panels");
  const manage = el("section", "admin-dashboard-panel");
  manage.appendChild(el("h3", "", "إدارة المحتوى"));
  const actions = el("div", "admin-dashboard-actions");
  const go = (icon,title,sub,fn)=>{const b=el("button","admin-dashboard-action");b.type="button";b.innerHTML='<span class="admin-dashboard-action-icon">'+icon+'</span><span><b>'+title+'</b><small>'+sub+'</small></span>';b.addEventListener("click",fn);actions.appendChild(b);};
  go("📚","المواد","إضافة وتعديل الروابط والحالة",()=>openMaterialsAdmin());
  go("📅","الجدول","إضافة وتعديل المواعيد",()=>openScheduleAdmin());
  go("📎","مرفقات المواد","إدارة مرفقات كل مادة",()=>openMaterialsAdmin());
  go("📬","المنشورات","فتح المنشورات ومراجعتها",()=>openDevNav("posts"));
  go("📝","التكاليف","إدارة التكاليف المنشورة",()=>openDevNav("tasks"));
  go("📰","النشرة الأسبوعية","إضافة وتعديل أعداد الـPDF",()=>openDevNav("newsletter"));
  go("🗂️","الأقسام","إنشاء وترتيب وإظهار الأقسام الديناميكية",()=>openSectionsAdmin());
  actions.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{setTimeout(()=>{if(state.active!=="__admin_dashboard__"){}},0);}));
  manage.appendChild(actions); panels.appendChild(manage);

  const system = el("section", "admin-dashboard-panel");
  system.appendChild(el("h3", "", "إدارة النظام"));
  const list = el("div", "admin-dashboard-list");
  const sys = (label,value,fn)=>{const row=el("div","admin-dashboard-list-row");row.appendChild(el("span","",label));const b=el("button","small",value);b.addEventListener("click",fn);row.appendChild(b);list.appendChild(row);};
  sys("المستخدمون", "فتح", ()=>setView("people"));
  sys("السجل", "فتح", ()=>setView("log"));
  sys("المظهر", "تعديل", ()=>setView("settings"));
  if(isFull()) sys("النسخة الاحتياطية", "تنزيل", downloadBackup);
  system.appendChild(list); panels.appendChild(system);
  wrap.appendChild(panels);
  box.appendChild(wrap);
}

function openMaterialsAdmin() {
  if (!isAdmin()) return;
  state.active = "__materials_admin__";
  state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
  state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
  setNavActive("materials");
  render();
}


function renderDynamicNav() {
  const box = $("dynamic-nav-sections");
  if (!box) return;
  box.replaceChildren();
  const custom = state.sections.filter(s => s.kind === "custom" && s.is_active !== false).sort((a,b) => (Number(a.sort_order)||0)-(Number(b.sort_order)||0));
  if (!custom.length) return;
  custom.forEach(sec => {
    const b = el("button", "side-nav-item" + (state.active === sec.id ? " active" : ""), "");
    b.dataset.nav = "section:" + sec.id;
    b.appendChild(el("span", "side-nav-icon", "📁"));
    b.appendChild(el("span", "side-nav-label", sec.title));
    b.addEventListener("click", () => openDevNav("section:" + sec.id));
    box.appendChild(b);
  });
}

function openSectionsAdmin() {
  if (!isAdmin()) return;
  state.active = "__sections_admin__";
  state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
  state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
  setNavActive("");
  render();
}

function renderSectionsAdmin() {
  const box = $("dashboard");
  if (!box) return;
  box.replaceChildren();
  const wrap = el("div", "settings-wrap");
  const head = el("div", "settings-head");
  const h = el("div");
  h.appendChild(el("h2", "dash-title", "إدارة الأقسام"));
  h.appendChild(el("p", "dash-sub", "أنشئ أقسامًا جديدة تظهر تلقائيًا للطلاب بدون تعديل الكود."));
  head.appendChild(h);
  const back = el("button", "small", "← لوحة الإدارة");
  back.addEventListener("click", openAdminDashboard);
  head.appendChild(back); wrap.appendChild(head);

  const create = el("section", "settings-card");
  create.appendChild(el("h3", "", "قسم جديد"));
  const title = el("input"); title.type = "text"; title.maxLength = 120; title.placeholder = "مثال: المراجعات";
  const order = el("input"); order.type = "number"; order.min = "0"; order.step = "1";
  order.value = String((state.sections.reduce((m,x)=>Math.max(m, Number(x.sort_order)||0),0))+1);
  const row = el("div", "row");
  row.appendChild(field("اسم القسم", title)); row.appendChild(field("الترتيب", order));
  create.appendChild(row);
  const add = el("button", "", "＋ إنشاء القسم");
  add.addEventListener("click", async () => {
    if (!isAdmin()) return;
    const name = title.value.trim();
    if (!name) { say("اسم القسم مطلوب"); return; }
    const n = Number(order.value);
    const { data, error } = await sb.from("sections").insert({ title:name, kind:"custom", sort_order:Number.isFinite(n)?n:0, is_active:true }).select("id,title,kind,sort_order,is_active").single();
    if (error) { say("تعذّر إنشاء القسم: " + (error.message || "")); return; }
    state.sections.push(data); title.value=""; order.value=String((state.sections.reduce((m,x)=>Math.max(m, Number(x.sort_order)||0),0))+1);
    renderDynamicNav(); say("تم إنشاء القسم"); render();
  });
  create.appendChild(add); wrap.appendChild(create);

  const list = el("section", "settings-card");
  list.appendChild(el("h3", "", "الأقسام الديناميكية"));
  const customs = state.sections.filter(s=>s.kind === "custom").sort((a,b)=>(Number(a.sort_order)||0)-(Number(b.sort_order)||0));
  if (!customs.length) list.appendChild(el("p", "meta", "لسه مفيش أقسام ديناميكية."));
  customs.forEach(sec => {
    const card = el("div", "dash-item");
    const main = el("div", "dash-item-main");
    const itemCount = state.items.filter(x => String(x.section_id) === String(sec.id) && !x.deleted_at).length;
    main.appendChild(el("div", "dash-item-title", "📁 " + sec.title));
    main.appendChild(el("div", "dash-meta", "الترتيب: " + (Number(sec.sort_order)||0) + " · " + itemCount + " عنصر · " + (sec.is_active === false ? "مخفي" : "ظاهر")));
    card.appendChild(main);
    const actions = el("div", "dash-actions");
    const ordered = customs;
    const idx = ordered.findIndex(x => String(x.id) === String(sec.id));
    const move = async (direction) => {
      const other = ordered[idx + direction];
      if (!other) return;
      const a = Number(sec.sort_order) || 0;
      const b = Number(other.sort_order) || 0;
      const first = await sb.from("sections").update({sort_order:b}).eq("id", sec.id);
      if (first.error) return say("تعذّر تغيير ترتيب القسم");
      const second = await sb.from("sections").update({sort_order:a}).eq("id", other.id);
      if (second.error) { await sb.from("sections").update({sort_order:a}).eq("id", sec.id); return say("تعذّر تغيير ترتيب القسم"); }
      sec.sort_order = b; other.sort_order = a;
      state.sections.sort((x,y)=>(Number(x.sort_order)||0)-(Number(y.sort_order)||0));
      renderDynamicNav(); render(); say("تم تغيير ترتيب القسم");
    };
    const up = el("button", "small", "↑");
    up.title = "تحريك لأعلى"; up.disabled = idx <= 0; up.addEventListener("click", () => move(-1));
    const down = el("button", "small", "↓");
    down.title = "تحريك لأسفل"; down.disabled = idx >= ordered.length - 1; down.addEventListener("click", () => move(1));
    actions.append(up, down);
    const edit = el("button", "small", "تعديل");
    edit.addEventListener("click", async () => {
      const name = prompt("اسم القسم", sec.title);
      if (name === null) return;
      const clean = name.trim(); if (!clean) return say("اسم القسم مطلوب");
      const raw = prompt("ترتيب القسم", String(sec.sort_order ?? 0));
      if (raw === null) return;
      const n = Number(raw); if (!Number.isFinite(n)) return say("الترتيب لازم يكون رقمًا");
      const { error } = await sb.from("sections").update({title:clean, sort_order:n}).eq("id",sec.id);
      if (error) return say("تعذّر التعديل");
      sec.title=clean; sec.sort_order=n; state.sections.sort((a,b)=>(Number(a.sort_order)||0)-(Number(b.sort_order)||0)); renderDynamicNav(); say("تم التعديل"); render();
    });
    const toggle = el("button", "small", sec.is_active === false ? "إظهار" : "إخفاء");
    toggle.addEventListener("click", async () => {
      const next = sec.is_active === false;
      const { error } = await sb.from("sections").update({is_active:next}).eq("id",sec.id);
      if (error) return say("تعذّر تغيير حالة القسم");
      sec.is_active=next; renderDynamicNav(); say(next?"تم إظهار القسم":"تم إخفاء القسم"); render();
    });
    const open = el("button", "small", "فتح");
    open.addEventListener("click", ()=>openDevNav("section:"+sec.id));
    const del = el("button", "small danger", "حذف");
    del.addEventListener("click", async () => {
      const count = state.items.filter(x=>String(x.section_id)===String(sec.id)).length;
      if (count) return say("القسم فيه عناصر. احذف أو انقل العناصر أولًا.");
      if (!confirm("حذف قسم «"+sec.title+"» نهائيًا؟")) return;
      const { error } = await sb.from("sections").delete().eq("id",sec.id);
      if (error) return say("تعذّر حذف القسم");
      state.sections = state.sections.filter(x=>x.id!==sec.id); renderDynamicNav(); say("تم حذف القسم"); render();
    });
    actions.append(edit,toggle,open,del); card.appendChild(actions); list.appendChild(card);
  });
  wrap.appendChild(list); box.appendChild(wrap);
}

function renderAdminNav() {
  const box = $("admin-nav-extra");
  if (!box) return;
  box.replaceChildren();
  if (!isAdmin()) { box.hidden = true; return; }
  box.hidden = false;

  const title = el("div", "admin-nav-title", "إدارة");
  box.appendChild(title);

  const add = (label, fn) => {
    const b = el("button", "admin-nav-item", label);
    b.addEventListener("click", fn);
    box.appendChild(b);
  };

  // المحتوى
  add("🧭 لوحة الإدارة", openAdminDashboard);
  add("📚 إدارة المواد", openMaterialsAdmin);
  add("📝 إدارة التكاليف", () => openDevNav("tasks"));
  add("📅 إدارة الجدول", openScheduleAdmin);
  add("📰 إدارة النشرة", () => openDevNav("newsletter"));
  add("📬 المنشورات", () => openDevNav("posts"));
  add("🗂️ إدارة الأقسام", openSectionsAdmin);

  // النظام — صلاحيات أعلى فقط حيث يلزم
  box.appendChild(el("div", "admin-nav-title", "النظام"));
  add("👥 المستخدمون", () => { state.logLimit = 100; setView("people"); });
  if (isFull()) {
    add("🧾 السجل", () => { state.logLimit = 100; setView("log"); });
    add("💾 النسخة الاحتياطية", downloadBackup);
  }
  add("🎨 إعدادات المظهر", () => setView("settings"));
}

async function openScheduleAdmin() {
  if (!isAdmin()) return;
  showLoading(true);
  let sec = findSectionByKind("schedule");
  if (!sec) {
    const maxOrder = state.sections.reduce((m, x) => Math.max(m, Number(x.sort_order) || 0), 0);
    const { data, error } = await sb.from("sections").insert({
      title: "الجدول",
      kind: "schedule",
      sort_order: maxOrder + 1,
      is_active: true
    }).select("id,title,kind,sort_order").single();
    if (error) {
      showLoading(false);
      say("تعذّر إنشاء قسم الجدول");
      return;
    }
    sec = data;
    state.sections.push(sec);
  }
  showLoading(false);
  state.active = "__schedule_admin__";
  state.form = null; state.pform = null; state.postForm = null; state.postFocus = null;
  state.trash = false; state.filter = "all";
  setNavActive("schedule");
  render();
}

function renderSavedAccounts() {
  const box = $("saved-accounts");
  const iosHelp = $("ios-login-help");
  if (iosHelp) iosHelp.hidden = !window.IS_IOS;
  if (!box) return;
  box.replaceChildren();
  let name = "";
  try { name = localStorage.getItem("tg_login_name") || ""; } catch (e) {}
  $("login-label").textContent = name ? "Login as " + name : "الدخول بتيليجرام";
  $("login-label").hidden = false;
  $("tg-slot").hidden = false;
}

const anonymousLoginButton=$("anonymous-login"); if (anonymousLoginButton) anonymousLoginButton.addEventListener("click", onAnonymousLogin);

async function showProfile() {
  showLoading(true);
  hideAll();
  $("login-box").hidden = true;
  $("pending-box").hidden = true;
  let sessionResult;
  try {
    sessionResult = await withTimeout(sb.auth.getSession(), 10000, "SESSION_TIMEOUT");
  } catch (e) {
    showLoading(false);
    $("login-box").hidden = false;
    renderSavedAccounts();
    mountTelegramRedirectButton();
    say("تعذّر الاتصال بالحساب — جرّبي تحديث الصفحة", true);
    return false;
  }
  const { data: { session } } = sessionResult;
  if (!session) {
    showLoading(false);
    $("logout").hidden = true;
    $("login-box").hidden = false;
    renderSavedAccounts();
    mountTelegramRedirectButton();
    return;
  }
  state.userId = session.user.id;
  state.isAnonymous = !!session.user.is_anonymous;
  $("logout").hidden = false;
  $("side-nav").hidden = false;
  if (state.isAnonymous) {
    state.role = "guest";
    state.chosen = true;
    state.botOk = null;
    renderAdminNav();
    $("hello").textContent = "WELCOME / GUEST";
    const [okC, okD] = await withTimeout(Promise.all([loadCourses(), loadData()]), 25000, "GUEST_BOOTSTRAP_TIMEOUT").catch(() => [false, false]);
    showLoading(false);
    if (!okC || !okD) { say("تعذّر تحميل المحتوى كزائر — جرّبي تحديث الصفحة", true); return false; }
    $("courses-btn").hidden = false; $("links-fab").hidden = false; $("manage-btn").hidden = true; $("log-btn").hidden = true; $("people-btn").hidden = true; $("backup-btn").hidden = true;
    setView("app");
    return true;
  }
  let profileResult;
  try {
    profileResult = await withTimeout(
      sb.from("profiles").select("first_name, role, approved, courses_chosen, bot_ok").eq("id", state.userId).single(),
      15000,
      "PROFILE_TIMEOUT"
    );
  } catch (e) {
    showLoading(false);
    $("login-box").hidden = false;
    renderSavedAccounts();
    mountTelegramRedirectButton();
    say("تعذّر تحميل الحساب — جرّبي تحديث الصفحة", true);
    return false;
  }
  const { data, error } = profileResult;
  if (error || !data) {
    showLoading(false);
    $("login-box").hidden = false;
    renderSavedAccounts();
    mountTelegramRedirectButton();
    say("تعذّر تحميل الحساب — جرّبي تسجيل الدخول مرة أخرى", true);
    return false;
  }
  try { localStorage.setItem("tg_login_name", data.first_name || ""); } catch (e) {}
  state.isAnonymous = false;
  state.role = data.role;
  renderAdminNav();
  state.chosen = !!data.courses_chosen;
  state.botOk = data.bot_ok;
  if (!data.approved) {
    showLoading(false);
    $("welcome").textContent = "أهلًا " + (data.first_name || "");
    $("pending-box").hidden = false;
    return;
  }
  $("hello").textContent = "WELCOME " + (data.first_name || "") + " / " + (roleLabels[data.role] || data.role);
  say("");
  const [okC, okD] = await withTimeout(Promise.all([loadCourses(), fetchData()]), 25000, "BOOTSTRAP_TIMEOUT").catch(() => [false, false]);
  showLoading(false);
  if (!okC || !okD) { showLoading(false); say("تعذّر تحميل بيانات الموقع — جرّبي تحديث الصفحة", true); return false; }
  $("courses-btn").hidden = false;
  $("links-fab").hidden = false;
  $("manage-btn").hidden = !isAdmin();
  $("log-btn").hidden = !isAdmin();
  $("people-btn").hidden = !isAdmin();
  $("backup-btn").hidden = true;
  if (isFull()) {
    sb.rpc("can_backup").then(({ data }) => { $("backup-btn").hidden = data !== true; });
  }
  if (!state.chosen && state.courses.some((c) => c.is_active)) setView("picker");
  else setView("app");
}
async function onAnonymousLogin() {
  const btn=$("anonymous-login"); if (btn) btn.disabled=true;
  showLoading(true); say("");
  try {
    const { error } = await sb.auth.signInAnonymously();
    if (error) throw error;
    await showProfile();
  } catch (e) {
    showLoading(false);
    $("login-box").hidden=false;
    renderSavedAccounts();
    const msg=String(e?.message||"");
    say(msg.toLowerCase().includes("anonymous")?"دخول الزائر غير مفعّل على المشروع بعد.":"تعذّر الدخول كزائر — جرّبي مرة أخرى",true);
  } finally { if (btn) btn.disabled=false; }
}

async function onTelegramAuth(user) {
  $("login-box").hidden = true;
  showLoading(true);
  say("");
  const fail = (m) => { showLoading(false); $("login-box").hidden = false; renderSavedAccounts(); mountTelegramRedirectButton(); say(m); };
  const { data, error } = await sb.functions.invoke("telegram-auth", { body: user });
  if (error || !data || !data.token_hash) { fail("فشل الدخول، برجاء إعادة المحاولة"); return; }
  const { error: e2 } = await sb.auth.verifyOtp({ token_hash: data.token_hash, type: "magiclink" });
  if (e2) { fail("فشل إكمال الدخول"); return; }
  await showProfile();
}
/* البتاعة العائمة: جروبات التواصل بتاعة كل مادة */
function renderLinksPanel() {
  const panel = $("links-panel");
  panel.replaceChildren();
  const kinds = [
    { key: "whatsapp_link", icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#25D366"/><path fill="#fff" d="M12 5.5a6.5 6.5 0 00-5.6 9.8L5.5 18.5l3.3-.9A6.5 6.5 0 1012 5.5zm3.8 9.3c-.2.5-1 .9-1.4 1-.4.1-.8.1-1.3-.1-.3-.1-.7-.2-1.2-.5-2.1-1-3.5-3-3.6-3.2-.1-.2-.9-1.2-.9-2.3 0-1.1.6-1.6.8-1.9.2-.2.4-.3.6-.3h.4c.1 0 .3 0 .5.4l.6 1.5c.1.1.1.3 0 .4l-.3.4c-.1.1-.2.3-.1.5.2.3.6 1 1.3 1.6.9.8 1.6 1 1.9 1.2.2.1.4.1.5-.1l.5-.6c.2-.2.3-.2.5-.1l1.3.6c.2.1.3.1.4.2.1.2.1.7-.1 1.2z"/></svg>' },
    { key: "teams_link", icon: '<svg viewBox="0 0 24 24"><rect width="24" height="24" rx="6" fill="#5059C9"/><text x="12" y="17" font-size="14" font-family="Arial,sans-serif" font-weight="700" fill="#fff" text-anchor="middle">T</text></svg>' },
    { key: "telegram_link", icon: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#229ED9"/><path fill="#fff" d="M17.5 7.2l-2.1 10.1c-.2.7-.6.9-1.2.6l-3.3-2.4-1.6 1.5c-.2.2-.3.3-.6.3l.2-3.3 6-5.4c.3-.2-.1-.4-.4-.2l-7.4 4.7-3.2-1c-.7-.2-.7-.7.1-1l12.5-4.8c.5-.2 1 .1.8 1z"/></svg>' },
    { key: "youtube_link", icon: '<svg viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="4" fill="#FF0000"/><path fill="#fff" d="M10 8l6 4-6 4z"/></svg>' },
  ];
  const list = state.courses
    .filter((c) => c.is_active)
    .map((c) => ({ c, n: kinds.reduce((s, k) => s + (c[k.key] ? 1 : 0), 0) }))
    .sort((a, b) => b.n - a.n);
  if (!list.length) { panel.appendChild(el("p", "center", "لا توجد مواد بعد")); return; }
  list.forEach(({ c }) => {
    const row = el("div", "links-row");
    row.appendChild(el("span", "name", c.name));
    const icons = el("div", "icons");
    kinds.forEach((k) => {
      if (c[k.key]) {
        const a = document.createElement("a");
        a.href = c[k.key]; a.target = "_blank"; a.rel = "noopener";
        a.innerHTML = k.icon;
        icons.appendChild(a);
      } else {
        const s = el("span", "dim");
        s.innerHTML = k.icon;
        icons.appendChild(s);
      }
    });
    row.appendChild(icons);
    panel.appendChild(row);
  });
}
$("links-fab").addEventListener("click", (e) => {
  e.stopPropagation();
  const panel = $("links-panel");
  panel.hidden = !panel.hidden;
  if (!panel.hidden) renderLinksPanel();
});
document.addEventListener("click", (e) => {
  if (e.target.closest("#links-fab, #links-panel")) return;
  $("links-panel").hidden = true;
});
$("courses-btn").addEventListener("click", () => setView("picker"));
$("manage-btn").addEventListener("click", () => setView("courses"));
$("people-btn").addEventListener("click", () => setView("people"));
$("log-btn").addEventListener("click", () => { state.logLimit = 100; setView("log"); });
$("backup-btn").addEventListener("click", downloadBackup);
$("logout").addEventListener("click", async () => { await sb.auth.signOut(); location.reload(); });

/* ===== Development navigation shell ===== */
function setNavActive(key) {
  document.querySelectorAll("#side-nav [data-nav]").forEach((b) => b.classList.toggle("active", b.dataset.nav === key));
}
function findSectionByKind(kind) {
  return state.sections.find((s) => s.kind === kind) || null;
}
function openDevNav(key) {
  if (!state.userId) return;
  setNavActive(key);
  if (key === "home") { state.active = null; setView("app"); return; }
  if (key === "materials") { state.active = "__materials__"; state.form=null; state.postForm=null; state.postFocus=null; state.trash=false; setView("app"); return; }
  if (key === "tasks") { state.active = "__tasks_admin__"; state.form=null; state.postForm=null; state.postFocus=null; state.trash=false; setView("app"); return; }
  if (key === "schedule") { state.active = "__schedule__"; state.form=null; state.postForm=null; state.postFocus=null; state.trash=false; setView("app"); return; }
  if (key === "posts") {
    state.active = "__posts__"; state.form = null; state.pform = null; state.postForm = null; state.postFocus = null; state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
    setView("app"); return;
  }
  if (key === "newsletter" && isAdmin()) {
    state.active = "__newsletter_admin__"; state.form = null; state.pform = null; state.postForm = null; state.postFocus = null; state.trash = false; state.filter = "all"; state.qform = null; state.answerForm = {};
    setView("app"); return;
  }
  const map = { tasks:"tasks", newsletter:"newsletter", qa:"qa" };
  if (map[key]) {
    const sec = findSectionByKind(map[key]);
    if (sec) { state.active = sec.id; state.form = null; state.pform = null; state.postForm = null; state.qform = null; state.answerForm = {}; setView("app"); return; }
  }
  if (key === "settings") { setView("settings"); return; }
  if (key === "sections-admin") { openSectionsAdmin(); return; }
  if (String(key).startsWith("section:")) {
    const id = String(key).slice("section:".length);
    const sec = state.sections.find(x => String(x.id) === id && x.kind === "custom" && (x.is_active !== false || isAdmin()));
    if (sec) { state.active = sec.id; state.form=null; state.pform=null; state.postForm=null; state.postFocus=null; state.trash=false; state.filter="all"; state.qform=null; state.answerForm={}; setView("app"); return; }
  }
  say("القسم ده لسه بنبنيه", true);
}
document.querySelectorAll("#side-nav [data-nav]").forEach((b) => b.addEventListener("click", () => openDevNav(b.dataset.nav)));
/* دخول تيليجرام على الآيفون: بيرجع للصفحة برابط فيه بيانات الدخول */
function mountTelegramRedirectButton() {
  if (!window.IS_IOS) return;
  var slot = $("tg-slot");
  if (!slot || slot.firstChild) return;
  var s = document.createElement("script");
  s.async = true;
  s.src = "https://telegram.org/js/telegram-widget.js?22";
  s.setAttribute("data-telegram-login", "MATHDEPARTMENT_BOT");
  s.setAttribute("data-size", "large");
  s.setAttribute("data-request-access", "write");
  s.setAttribute("data-auth-url", location.origin + location.pathname.replace(/index\.html$/, ""));
  slot.appendChild(s);
}
function readTelegramReturn() {
  try {
    var q = new URLSearchParams(location.search);
    if (!q.get("hash") || !q.get("id") || !q.get("auth_date")) return null;
    var keys = ["id", "first_name", "last_name", "username", "photo_url", "auth_date", "hash"];
    var u = {};
    keys.forEach(function (k) { if (q.has(k)) u[k] = q.get(k); });
    history.replaceState(null, "", location.pathname);
    return u;
  } catch (e) { return null; }
}
var tgReturn = readTelegramReturn();
if (tgReturn) onTelegramAuth(tgReturn); else showProfile();

window.Math3Render = render;
export { onTelegramAuth, mountTelegramRedirectButton, readTelegramReturn, onAnonymousLogin };
